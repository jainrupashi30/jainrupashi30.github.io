## Assignment - SVM
## Name - Rupashi Jain
### Business Understanding:
## This business problem is to recognise hand written digits. Suppose that you have an image of a digit submitted by a user via a scanner, a tablet, or other digital devices. 
##The goal is to develop a model that can correctly identify the digit (between 0-9) written in an image. 
## We need to develop a model using Support Vector Machine, which can correctly classify the hand written digits 
## based on the pixel values given as features. 

## Data Understanding 
################################################################################
## For this problem we use  MNIST data which is a large database of handwritten digits, where we have pixel values for each digit aling with its label. 
## Since, the data is very huge, hence only 15% of the data is considered for model building, which is later on tested 
## on a bigger chunk of data. 
## First all the necessary packages were installed and loaded . 
#install.packages("caret")

#install.packages("kernlab")

#install.packages("dplyr")

#install.packages("readr")

#install.packages("ggplot2")

#install.packages("gridExtra")

#install.packages("Rcpp")
#install.packages("foreach")
#install.packages("doParallel")
library(ggplot2)

library(Rcpp)

library(caret)

library(dplyr)

library(readr)

library(plotly)

library(kernlab)

library(gridExtra)

library(foreach)

library(doParallel)

library(caTools)
# Remove existing memory space if any
remove(list=ls())

# read.csv() function is used to read given csv file into a data frame 
## Argument 'header' is set to False so that none of the column values is considered as a header. 
## Reading the train and test data provided. 
train <- read.csv("mnist_train.csv",header=F)
## Train data contains 60000 observations with 785 variables. 
test <- read.csv("mnist_test.csv",header=F)
## Test Data contains 10000 observations with 785 variables. 

## Used function summary() to have a quick glance at the values stored in different variables of the data frame. 
## Used function str() to see all the variable names and types. 
#summary(train)
#str(train)
## All the columns are numeric with each column containing the respective pixel value and the first column containing the value of the actual digit from 0 to 9. 
## set.seed() is used so that the same sample of data is picked up again and again when running in the same session of R. 

set.seed(100)

## Data Prepapration 
## Taking only 15% of the training data for further analysis. 
## USed function sample() for this. 
train.indices = sample(1:nrow(train), 0.15*nrow(train))

train_final <- train[train.indices,]

## Given appropriate names to the columns wherever required . Used function colnames[] for the same. 
## The first column contains the digit hence given it a name "Number" to distinguish it from the pixel values.
colnames(train_final)[1] <- "Number"
colnames(test)[1] <- "Number"

## Applying as.factor() on the digit label columns as they are levels/digits from 0 to 9  and should not be treated as numeric data 
train_final$Number <- as.factor(train_final$Number)
test$Number <- as.factor(test$Number)

## Identifying NA values if any . 
sapply(train_final, function(x) sum(is.na(x)))

## No NA values found in the data 

## Removing Duplicate values if any 
train_final <- train_final[!duplicated(train_final),]
## No duplicates found in the data 

## EDA 
## Plotting the graph of intensity of pixels for each digit. 
## First taking the mean of each row of the data frame train_final 
train_final$intensity <- apply(train_final[,-1], 1, mean)
## Then aggregating the intensity values of each digit and calculating the mean intensity. 
digit_intensity <- aggregate (train_final$intensity, by = list(train_final$Number), FUN = mean)

## PLotting the mean intensity of each digit to get a fair idea of how is the pixel intensity for each digit. 
plot <- ggplot(data=digit_intensity, aes(x=Group.1, y = x)) +  geom_bar(stat="identity")

plot + scale_x_discrete(limits=0:9) + xlab("digit label") +   ylab("average intensity")

## It can be seen from the graph that the 3,4,7,9 is more than the others . Surprisingly 1 has the maximum intensity. 

## Removing the new column intensity which was created just to plot the graph .
train_final <- train_final[,-786]
## Scaling . As the data contains values within a wide range of 0 to 255, hence devided each value by 255 to get uniformity in values. 
## This is done so that the model is not biased for huge amount of values for any particular column. 
## Used max() function to get maximum value in the data 

max(train_final[ ,2:ncol(train_final)]) 
# max pixel value is 255, hence used this to scale the data and that was acheived by dividing all the data values by 255. 
## This was done in both test and train data

train_final[ , 2:ncol(train_final)] <- train_final[ , 2:ncol(train_final)]/255

test[ , 2:ncol(test)] <- test[ , 2:ncol(test)]/255


## BUilding Linear model 
## Used function ksvm() to build the same. The attribute values for kernel is given as "Vanilladot" to
## build the linear model. 
## Used print() command to print the model results. 
Model_linear_1 <- ksvm(Number~ ., data = train_final, scale = FALSE, kernel = "vanilladot")
print(Model_linear_1)

## As per the model , the default value of c is 1, and training error is 0.001778.  

## Using the model built above to see how well it can predict values on the test data. 
## used predict() function for the same. 
Eval_linear<- predict(Model_linear_1, test[,-1])

#confusion matrix - Linear Kernel
confusionMatrix(Eval_linear,test$Number)

## Accuracy approx 92%
## c=1 as from above 

##                     Class: 0 Class: 1 Class: 2 Class: 3 Class: 4 Class: 5 Class: 6 Class: 7 Class: 8 Class: 9
##Sensitivity            0.9796   0.9850   0.9109   0.9000   0.9633   0.8722   0.9374   0.9212   0.8480   0.8731
##Specificity            0.9921   0.9946   0.9903   0.9843   0.9890   0.9883   0.9962   0.9932   0.9907   0.9928
## It can be observed  that digits 3, 5,8,9 have lower sensitivities comparatively.

#####################################################################
# Hyperparameter tuning and Cross Validation  - Linear - SVM 
######################################################################

# We will use the train function from caret package to perform crossvalidation
## Since the data size is very huge; so taken only a sample of smaller data i.e. 15% ; to perform cross validation. 
## Later on tested the result of cross validation on a larger set of data i.e. complete test data to check the accuracy. 
## train_tune data frame was created to perform cross validation quicker on a smaller set of data. 
## train_validation data frame was created to perform validation on another set of data to be sure of the results. 

## sample.split() was used to split the data into smaller chunks. 

train_tune_indices = sample.split(train_final$Number, SplitRatio = 0.15)
## train_tune_indices =  sample(1:nrow(train_final), 0.15*nrow(train_final))
train_tune <- train_final[train_tune_indices,]

train_tune_test <- train_final[!(train_tune_indices),]

train_validation_indices = sample.split(train_tune_test$Number, SplitRatio = 0.15)

train_validation <- train_final[train_validation_indices,]

#########################################################################
## traincontrol parameter is needed to pass to the train() command for cross validation. 

trainControl <- trainControl(method="cv", number=5)

# Number - Number of folds 
# Method - cross validation

metric <- "Accuracy"

# making a grid of C values. Taking different range of c values . using function expand.grid()
 
grid_1 <- expand.grid(C=seq(1, 5, by=1))

# Performing 5-fold cross validation
## Using train() function to perform cross validation of the hyperparameter c 
fit.svm_1 <- train(Number~., data=train_tune, method="svmLinear", metric=metric, 
                 tuneGrid=grid_1, trControl=trainControl)

# Printing cross validation result
print(fit.svm_1)
## using plot() to plot the results. 
plot(fit.svm_1)
# Best tune at C=1 as per the above range of C values.  
# Accuracy ~ 87%
## Accuracy is same for all vallues of c from 1 to 5 i.e. C>1 

## Checking the same on Validation Data to make sure the train_tune dataframe gives the correct results. 

fit.svm_1_validation <- train(Number~., data=train_validation, method="svmLinear", metric=metric, 
                   tuneGrid=grid_1, trControl=trainControl)

print(fit.svm_1_validation)
# Plotting "fit.svm" results
## This also gives the value of C as 1 and accuracy ~ 87%
plot(fit.svm_1_validation)

## Now trying grid for c values less than 1 
grid_2 <- expand.grid(C=seq(0.5, 1, by=0.1))

fit.svm_2 <- train(Number~., data=train_tune, method="svmLinear", metric=metric, 
                 tuneGrid=grid_2, trControl=trainControl)

print(fit.svm_2)

plot(fit.svm_2)

## Agian the accuracy is same for all the c values. Here the value of c comes as 0.5 
## Accuracy ~ 0.8529

##  Now trying grid for c values less than 0.5

grid_3 <- expand.grid(C=c(0.01,0.05,0.1,0.3,0.5))

fit.svm_3 <- train(Number~., data=train_tune, method="svmLinear", metric=metric, 
                   tuneGrid=grid_3, trControl=trainControl)

print(fit.svm_3)
## Accuracy ~ 0.88
## Value of c is 0.05 

plot(fit.svm_3)

## Validating for the Validation data using train_validation data frame. 
fit.svm_3_validation <- train(Number~., data=train_validation, method="svmLinear", metric=metric, 
                              tuneGrid=grid_3, trControl=trainControl)

print(fit.svm_3_validation)

plot(fit.svm_3_validation)
## Plot shows best accuracy for c as 0.05.
## Validation data also gives c as 0.05 . Hence, value of c is 0.05 with accuracy of approx 88%
###############################################################################


#Using Linear Kernel Validating the model on test data 
# For c= 0.5

Model_linear_2 <- ksvm(Number~ ., data = train_final, scale = FALSE, kernel = "vanilladot",C=0.5)

# Valdiating the model after cross validation on test data for C=0.5

Eval_linear_2<- predict(Model_linear_2, test[,-1])

#confusion matrix - Linear Kernel
confusionMatrix(Eval_linear_2,test$Number)

## Accuracy : 92.37 

## Checking for C value 0.05 

Model_linear_3 <- ksvm(Number~ ., data = train_final, scale = FALSE, kernel = "vanilladot",C = 0.05)
print(Model_linear_3)

## As per the model , the default value of c is 0.05. 
## Using the model to predict results on test data and see the accuracy. 
Eval_linear_3<- predict(Model_linear_3, test[,-1])

#confusion matrix - Linear Kernel
confusionMatrix(Eval_linear_3,test$Number)

## Accuracy is 93.26%
##Statistics by Class:
  
  ##                     Class: 0 Class: 1 Class: 2 Class: 3 Class: 4 Class: 5 Class: 6 Class: 7 Class: 8 Class: 9
##Sensitivity            0.9847   0.9868   0.9225   0.9218   0.9603   0.8834   0.9478   0.9232   0.8819   0.9029
##Specificity            0.9936   0.9956   0.9920   0.9879   0.9902   0.9903   0.9955   0.9944   0.9929   0.9928

## Hence for final linear model the c value comes out to be 0.05 with accuracy of approx 93.26% 
## Sensitivity is also good for all the classes ; relatively lower for 8 and 9 .

############################################################################################################################
## Using RBF Kernel model to see if the accuracy can further be improved. 
## passing parameter "rbfdot" to the ksvm() function .

Model_RBF_1 <- ksvm(Number~ ., data = train_final, scale = FALSE, kernel = "rbfdot")

print(Model_RBF_1)
## Following best default values of c and sigma were returned by the model. 
## sigma : 0.01064
## c: 1
## Training error : 0.017

## Checking the model on test data by using predict() function. 
Eval_RBF_1<- predict(Model_RBF_1, test[,-1])

#confusion matrix - RBF Kernel for Model_RBF_1
confusionMatrix(Eval_RBF_1,test$Number)

## Accuracy : 95.5%
## Digits 7,8,9 have comparatively little lower sensitivity ~ 93%; for rest all digits.  the sesitivity is above 93%. 
## For all the digits sensitivity is also good i.e. above 92%


#####################################################################
#Hyperparameter tuning and Cross Validation - Non-Linear - SVM 
## Checking if we can find better values for C and sigma which could result in better accuracy of the model. 
######################################################################


# Making grid of "sigma" and C values. 
grid_r_1 <- expand.grid(sigma=c(0.025,0.05), C=c(0.1,0.5,1,2))

# Performing 5-fold cross validation; using train_tune data frame .
## Using train() function to perform cross validation. Number of folds is 5 ; method is cross validation. 
## Sigma and C values are the ones mentioned in the grid above. 
fit.svm_radial_1 <- train(Number~., data=train_tune, method="svmRadial", metric=metric, 
                        tuneGrid=grid_r_1, trControl=trainControl(method = "cv", number = 5),preProcess = NULL)

# Printing cross validation result
print(fit.svm_radial_1)
## sigma : 0.025
## c: 2 
## Accuracy ~ 94.29%
# Plotting model results using plot()
plot(fit.svm_radial_1)

## Performing the same steps to see if c and sigma can be further optimised. 
# Optimising C  and sigma further

grid_r_2 <-  expand.grid(sigma=c(0.01,0.1), C=c(1,2,3))

fit.svm_radial_2 <- train(Number~., data=train_tune, method="svmRadial", metric=metric, 
                         tuneGrid=grid_r_2, trControl=trainControl(method = "cv", number = 5),preProcess = NULL)

print(fit.svm_radial_2) 

## Sigma is  0.01 
## C : 3 
## Accuracy : 94.22%


plot(fit.svm_radial_2)

grid_r_3 <-  expand.grid(sigma=c(0.005,0.01), C=seq(3,6,by=1))

fit.svm_radial_3 <- train(Number~., data=train_tune, method="svmRadial", metric=metric, 
                          tuneGrid=grid_r_3, trControl=trainControl(method = "cv", number = 5),preProcess = NULL)

print(fit.svm_radial_3) 

## Sigma is again 0.01 
## C : 6 
## Accuracy : 93.8%

plot(fit.svm_radial_3)

grid_r_4 <-  expand.grid(sigma=c(0.025,0.01,0.05), C=seq(1,4,by=1))

fit.svm_radial_4 <- train(Number~., data=train_tune, method="svmRadial", metric=metric, 
                          tuneGrid=grid_r_4, trControl=trainControl(method = "cv", number = 5),preProcess = NULL)

print(fit.svm_radial_4)

##  sigma = 0.01 and C = 3.
## Accuracy : 94.7%

plot(fit.svm_radial_4)


grid_r_5 <-  expand.grid(sigma=c(0.001,0.025), C=seq(1,4,by=1))

fit.svm_radial_5 <- train(Number~., data=train_tune, method="svmRadial", metric=metric, 
                          tuneGrid=grid_r_5, trControl=trainControl(method = "cv", number = 5),preProcess = NULL)

print(fit.svm_radial_5)

##  sigma = 0.025 and C = 2.
## Accuracy : 94.7%

plot(fit.svm_radial_5)

grid_r_6 <- expand.grid(sigma=c(0.025,0.05,0.01), C=c(0.1,0.5,1,2))

# Performing 5-fold cross validation; using train_tune data frame .
## Using train() function to perform cross validation. Number of folds is 5 ; method is cross validation. 
## Sigma and C values are the ones mentioned in the grid above. 
fit.svm_radial_6 <- train(Number~., data=train_tune, method="svmRadial", metric=metric, 
                          tuneGrid=grid_r_6, trControl=trainControl(method = "cv", number = 5),preProcess = NULL)

print(fit.svm_radial_6)
## Sigma : 0.025
## C: 2 
## Accuracy : 95.18%

## Validating the same on validation data for a couple of sigma and c values .
## Commenting this part as it was used only for validating if the train_tune data is predicting correct or not 
##fit.svm_radial_validate_1 <- train(Number~., data=train_validation, method="svmRadial", metric=metric, 
  ##                                 tuneGrid=grid_r_1, trControl=trainControl(method = "cv", number = 5),preProcess = NULL)

##print(fit.svm_radial_validate_1)

##fit.svm_radial_validate_2 <- train(Number~., data=train_validation, method="svmRadial", metric=metric, 
  ##                                 tuneGrid=grid_r_2, trControl=trainControl(method = "cv", number = 5),preProcess = NULL)

##print(fit.svm_radial_validate_2)

##fit.svm_radia_validate_3 <- train(Number~., data=train_validation, method="svmRadial", metric=metric, 
  ##                                tuneGrid=grid_r_3, trControl=trainControl(method = "cv", number = 5),preProcess = NULL)

##print(fit.svm_radia_validate_3)

## The values of sigma and c  returned by validation data i.e. train_validation are also the same. Hence going forward with these values 

## Below is a summary of all the Sigma and C value combinations obtained by using train()and performing different iterations. 
##  Sr.No.          Sigma Value              C Value                  Accuracy on the train data 
##    1                 0.01                   3                       Got these values from more than one fit.svm and the range is between 94.2% to 94.7%
##    2                 0.025                  2                       Got these values from more than one fit.svm and the range is between 94.2% to 94.7% 
##    3                 0.01                   6                       93.8%
#######################################################################################################################################################
# Checking overfitting - Non-Linear - SVM
#########################################################################################################################################3

# Validating the model results on test data
#1 Building model based on c and sigma values obtained from train() above as mentioned in summary for optimal sigma and c values above 
## Model  For C=2 and Sigma =0.025 
Model_RBF_1 <- ksvm(Number~ ., data = train_final, scale = FALSE, kernel = "rbfdot",C = 2, kpar=list(sigma=0.025))

## Evaluating the model by first predicting on test data and then building Confusion Matrix. 

evaluate_non_linear_1 <- predict(Model_RBF_1, test[,-1])

confusionMatrix(evaluate_non_linear_1, test$Number)

# Results:
## 
## Accuracy  0.9672
##Statistics by Class:
  
##                     Class: 0  Class: 1  Class: 2 Class: 3 Class: 4 Class: 5 Class: 6 Class: 7 Class: 8 Class: 9
##Sensitivity            0.9898   0.9903   0.9690   0.9733   0.9725   0.9585   0.9739   0.9465   0.9548   0.9405
##Specificity            0.9963   0.9982   0.9957   0.9958   0.9958   0.9967   0.9973   0.9968   0.9956   0.9954

## 2 Checking for C as 3 and sigma as 0.01
Model_RBF_2 <- ksvm(Number~ ., data = train_final, scale = FALSE, kernel = "rbfdot",C = 3, kpar=list(sigma=0.01))

evaluate_non_linear_2 <- predict(Model_RBF_2, test[,-1])

confusionMatrix(evaluate_non_linear_2, test$Number)

## Results: 
## Accuracy : 0.9605
##Statistics by Class:
  
##                      Class: 0 Class: 1 Class: 2 Class: 3 Class: 4 Class: 5 Class: 6 Class: 7 Class: 8 Class: 9
##Sensitivity            0.9908   0.9894   0.9603   0.9634   0.9695   0.9496   0.9635   0.9407   0.9405   0.9336
##Specificity            0.9956   0.9975   0.9945   0.9943   0.9941   0.9955   0.9976   0.9965   0.9953   0.9951

## 3 Checking for C as 6 and sigma as 0.01
Model_RBF_3 <- ksvm(Number~ ., data = train_final, scale = FALSE, kernel = "rbfdot",C = 6, kpar=list(sigma=0.01))

evaluate_non_linear_3 <- predict(Model_RBF_3, test[,-1])

confusionMatrix(evaluate_non_linear_3, test$Number)


## Results:
## Accuracy : 0.9633
##Statistics by Class:
  
##                      Class: 0 Class: 1 Class: 2 Class: 3 Class: 4 Class: 5 Class: 6 Class: 7 Class: 8 Class: 9
##Sensitivity            0.9888   0.9903   0.9651   0.9683   0.9756   0.9496   0.9666   0.9465   0.9415   0.9366
##Specificity            0.9958   0.9974   0.9950   0.9949   0.9945   0.9958   0.9978   0.9968   0.9955   0.9959

#####################################################################################################################


## Hence it can be concluded that the best RBF model would be the one with below details : 
## C=2 and Sigma =0.025 
## Accuracy ~ 96.7%
##Statistics by Class:

##                     Class: 0  Class: 1  Class: 2 Class: 3 Class: 4 Class: 5 Class: 6 Class: 7 Class: 8 Class: 9
##Sensitivity            0.9898   0.9903   0.9690   0.9733   0.9725   0.9585   0.9739   0.9465   0.9548   0.9405
##Specificity            0.9963   0.9982   0.9957   0.9958   0.9958   0.9967   0.9973   0.9968   0.9956   0.9954

## Also it can be seen that the sensitivity is very good for all the digits. Hence, in most of the cases it can correctly identify the digits. 