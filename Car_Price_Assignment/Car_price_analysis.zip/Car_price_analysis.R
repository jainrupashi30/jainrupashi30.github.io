## Module : Linear Regression Assignment 
## Name : Rupashi Jain
## C7 June 2018
## Instruction : Set working directory and place the data file in that path  
## Install required packages like tidyr,dplyr ,MASS,car
## setwd... Set the working directory
## setwd("~/rupashi/Data Science/Course_3/Assignment")
## setting all the required libraries

library(tidyr)
library(dplyr)
library(MASS)
library(car)
library(ggplot2)

# Reading the Data . 
#read.csv() is used to Read the Car Price Data file  and storing it in respective data frame i.e. car_price
## Here String as Factors is given value true as the data contains either numerical data or categorical which will be later on converted to numerical for linear regression. 
car_price <- read.csv("CarPrice_Assignment.csv",stringsAsFactors = TRUE)

## Used function summary() to have a quick glance at the values storedd in different variables of the data frame. 
## Used function str() to see all the variable names and types. 
summary(car_price)
str(car_price)

## Data Cleaning 
## 1. Checking for NA values in the dataframe. Used function colsums() and is.na() to find the NA values .
car_price <- car_price[colSums(!is.na(car_price))!=0]
## There are no NA values in the dataframe as the number of observations remain same. 

## 2. Check for duplicate values. Used duplicated() function which returns duplicate values if any. 
 car_price <- car_price[!duplicated(car_price),]
 ## It is observed that there are no duplicate values in the dataframe
 
 ## 3. Separating Car name from Company name in the column Car Name as Company name would only be significant for further 
 ## analysis because Company name could effect the price of the car and not the car name. Hence just extracted the company name 
 ## from this column. 
 car_price <- separate(car_price, CarName , into=c("Company"),extra='drop')
 ## used str() to see the type and the values  
 str(car_price$Company)
 ## Used function unique() to identify the unique values stored in the Company names . 
 unique(car_price$Company)
 ## It was identified that there are spelling errors in the Company names ; hence performed spell check and corrected them. 
 ## 3. Performing Spell Check on the columns which could have errors. Used function unique() to get unique values
 ## First applied function tolower() to get all the values stored in the column Company in the same case. 
 car_price$Company <- tolower(car_price$Company)
 car_price$Company[which(car_price$Company=="maxda")] <- "mazda"
 car_price$Company[which(car_price$Company=="vw")] <- "volkswagon"
 
 car_price$Company[which(car_price$Company=="porcshce")] <- "porsche"
 
 ##car_price$Company[which(car_price$Company=="porcshce")] <- "porsche"
 
 car_price$Company[which(car_price$Company=="toyouta")] <- "toyota"
 
 car_price$Company[which(car_price$Company=="vokswagen")] <- "volkswagen"
 
 car_price$Company[which(car_price$Company=="volkswagen")] <- "volkswagon"
 
 ## Performed spell check similarly on the column Carbody. 
## used str() to see the type and the values  
 str(car_price$carbody)
 ## Used function unique() to identify the unique values stored in the Company names . 
 unique(car_price$carbody)
 ## No spelling errors were identified. 
 
 ## Performed spell check similarly on the columnn Engine type 
 str(car_price$enginetype)
 unique(car_price$enginetype)
 ## No spelling errors were identified.
 
## Dummy variable creation and Creating levels for all the Categorical Variables for further regression analysis. 
## Used function str() to see the structure of the dataframe to identify all the categorical columns for which Levels and dummy variables need to be created. 
## For Categorical variables with 2 levels; the categories were converted into levels 0 and 1. 
## For Categorical variables with 3 and more leves; dummy variables were created which store values in form of 0 and 1. 
 
 str(car_price)


##1 .Fuel Type : Levels Created for Fuel Type variable. Used function levels() to assign the levels specified i.e. 0 and 1 for the two levels 
## Here there are 2 levels Diesel and Gas. 
levels(car_price$fueltype) <- c(1,0)

## diesel given value :1  and gas : 0 
## Now assigning these levels created above to the column name fuel type and replacing Deisel and Gas with these levels 1 and 0.
## as.numeric() is used when creating levels for all the categorical type variables , to convert it into numeric type so that regression analysis can be performed. 
car_price$fueltype <- as.numeric(levels(car_price$fueltype))[car_price$fueltype]


##2 aspiration :  Created Levels similarly for the variable aspiration . Used levels() function here.  
## std :1, turbo : 0 
levels(car_price$aspiration) <-  c(1,0)
car_price$aspiration <- as.numeric(levels(car_price$aspiration))[car_price$aspiration]

## 3 Doornumber : Created Levels similarly for the variable Door number . Used levels() function here.
## two :0 ; four :1 
levels(car_price$doornumber) <- c(1,0)
car_price$doornumber <- as.numeric(levels(car_price$doornumber))[car_price$doornumber]

## 4 Enginelocation : Created Levels similarly for the variable Enginelocation . Used levels() function here.
##front :1 , rear : 0 
levels(car_price$enginelocation) <-  c(1,0)
car_price$enginelocation <- as.numeric(levels(car_price$enginelocation))[car_price$enginelocation]

##5 Creating Dummy Variables for more than 3 levels . 
## Used model.matrix() function to create dummy variables for the specified variable in the data frame. 
## Drive wheel
## Stored the dummy variables in a dataframe . 
dummy_1 <- data.frame(model.matrix( ~drivewheel, data = car_price))
## View() used to view the dummy variables created
##View(dummy_1)
## Removing first column as all the values in this column are 1 hence of no significance.  
dummy_1 <- dummy_1[,-1]
## Used function cbind() to add those variables created in the main dataframe.
## Also removed the original categorical variable drivewheel and added the dummy variables created in the above step to the main data frame . 
car_price <- cbind(car_price[,-8], dummy_1)

##6 Performed the same steps as above for the Variable  Car Company Name 

dummy_2 <- data.frame(model.matrix( ~Company, data = car_price))

##View(dummy_2)

dummy_2 <- dummy_2[,-1]

car_price <- cbind(car_price[,-3], dummy_2)

## 7 Performed the same steps as above for the Variable Carbody 

dummy_3 <- data.frame(model.matrix( ~carbody, data = car_price))

##View(dummy_3)

dummy_3 <- dummy_3[,-1]

car_price <- cbind(car_price[,-6], dummy_3)

## 8 Performed the same steps as above for the Variable enginetype

dummy_4 <- data.frame(model.matrix( ~enginetype, data = car_price))

##View(dummy_4)

dummy_4 <- dummy_4[,-1]

car_price <- cbind(car_price[,-12], dummy_4)

##9 Performed the same steps as above for the Variable cylindernumber

dummy_5 <- data.frame(model.matrix( ~cylindernumber, data = car_price))

##View(dummy_5)

dummy_5 <- dummy_5[,-1]

car_price <- cbind(car_price[,-12], dummy_5)

## 10 Performed the same steps as above for the Variable fuelsystem


dummy_6 <- data.frame(model.matrix( ~fuelsystem, data = car_price))

##View(dummy_6)

dummy_6 <- dummy_6[,-1]

car_price <- cbind(car_price[,-13], dummy_6)


## 11 Performed the same steps as above for the symboling 
## First converted the symboling variable to factor type as it is categorical variable and dummy variables need to be created. 
car_price$symboling <- as.factor(car_price$symboling)
str(car_price)

dummy_7 <- data.frame(model.matrix( ~symboling, data = car_price))

##View(dummy_7)

dummy_7 <- dummy_7[,-1]

car_price <- cbind(car_price[,-2], dummy_7)

## Used str() to see the structure of the data frame after creating all Dummy variables and levels. 
str(car_price)
## Now all the variables are created into dummy and levels with numeric data type. 

## Model Building 
# separate training and testing data to perform regression analysis. 
## set.seed() is used so that the same model is generated when run again in this R session. 
set.seed(100)

## Considered 70 percent of the data as train data and stored the value of indices in the trainindices and later on will pass this variable to the dataframe to separate test and train data set. 
## sample() function is used to get 70 percent of the data which will be used as train. 
trainindices= sample(1:nrow(car_price), 0.7*nrow(car_price))

## Storing train data in dataframe train . Model building will be done on this data frame. 
train <- car_price[trainindices,]

## Storing the remaining values i.e. all values except trainindices, in data frame test.Model testing will be done on this data frame .  
test <- car_price[-trainindices,]


## Build model 1 containing all the variables . Use function lm() to create linear model for Proce dependant variable and all the independant variables present in the data frame. 
## summary() function is used to get the summary of the model which will specify the R and adjusted R square values along with list of all the independant variables on which dependant variable can depend. 
model_1 <-lm(price~.,data=train)

summary(model_1)

## We have 60 variables considered into the model. 

## Used StepAIC function at the begining to get rid of all the non significant variables and then further perform iterations on the model created to get the best model . 
# In stepAIC function, we pass our first model i.e model_1 and 
# direction is ser as both, because in stepwise,  both the forward selection 
# of variables and backward elimination of variables happen simultaneously 
step <- stepAIC(model_1, direction="both")
# stepAIC makes multiple calls while checking which variables to keep
# The last call that step makes, contains only the variables it considers to be important in the model. 
# some insignifican variables have been removed. 
# Now store the last model equation of stepwise method into an object called model_2
step

## model 2 . Executing the model_2 obtained from step above. Used lm() function to create a linear model with the dependant variable as price and the independant variables as mentioned in each model after ~ . 

model_2 <-  lm(formula = price ~ car_ID + aspiration + enginelocation + carwidth + 
                 curbweight + enginesize + stroke + peakrpm + citympg + drivewheelrwd + 
                 Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth + Companyporsche + Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo + carbodyhardtop + carbodyhatchback + carbodysedan + 
                 carbodywagon + enginetyperotor + cylindernumberfour + cylindernumbersix + 
                 fuelsystem2bbl + symboling.1 + symboling0 + symboling3 + 
                 symboling2, data = train)

## See the summary of the model_2 to have a look at the p values and the R square and adjusted R square of all the independant variables. 

summary(model_2)
## R-squared : 0.9815,	Adjusted R-squared:  0.9745 

## Now to identify mutlicollinearity and the order in which the variables can be removed from the model used function vif().
# If the VIF is above 2 or 5 as the business goal says,we can remove 
# the variables if they are statistically insignificant i.e. p>0.05

## used the function sort() to sort all the VIF values. 
## 
sort(vif(model_2))

## VIF : Reading the high VIFs and corresponding p values. Considered only those variables for removal which have high 
## VIF and high p. Variables with high VIF and low p are not removed as they can be statistically significant, 
## Also at each step compared the value of the Adjusted R square with the pervioud model to make sure Adjusted R square doesn't fall significanlty on removing any independant variable. 
## Removing curbweight having high VIF i.e.  26.069347 and high p when copared to other high VIF value variables. 

model_3 <-    lm(formula = price ~ car_ID + aspiration + enginelocation + carwidth + 
                   enginesize + stroke + peakrpm + citympg + drivewheelrwd + 
                   Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                   Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                   Companypeugeot + Companyplymouth + Companyporsche + Companyrenault + 
                   Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                   Companyvolvo + carbodyhardtop + carbodyhatchback + carbodysedan + 
                   carbodywagon + enginetyperotor + cylindernumberfour + cylindernumbersix + 
                   fuelsystem2bbl + symboling.1 + symboling0 + symboling3 + 
                   symboling2, data = train)

summary(model_3)
## Multiple R-squared:  0.9797,	Adjusted R-squared:  0.9722. Since R value does not drop significantly hence it is okay to remove the independant variable. 
## Again performing vif() to identify which variable to be removed next. Same set of steps were performed at each iteration. 
sort(vif(model_3))

## Removing carbodysedan based on high VIF and p value. and creating next model without carbodysedan

model_4 <-  lm(formula = price ~ car_ID + aspiration + enginelocation + carwidth + 
                 enginesize + stroke + peakrpm + citympg + drivewheelrwd + 
                 Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth + Companyporsche + Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo + carbodyhardtop + carbodyhatchback +  
                 carbodywagon + enginetyperotor + cylindernumberfour + cylindernumbersix + 
                 fuelsystem2bbl + symboling.1 + symboling0 + symboling3 + 
                 symboling2, data = train)

summary(model_4)
## Multiple R-squared:  0.9785,	Adjusted R-squared:  0.9709 
sort(vif(model_4))
## Again performing vif() to identify which variable to be removed next.

## Removing  cylindernumberfour

model_5 <-  lm(formula = price ~ car_ID + aspiration + enginelocation + carwidth + 
                 enginesize + stroke + peakrpm + citympg + drivewheelrwd + 
                 Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth + Companyporsche + Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo + carbodyhardtop + carbodyhatchback +  
                 carbodywagon + enginetyperotor +  cylindernumbersix + 
                 fuelsystem2bbl + symboling.1 + symboling0 + symboling3 + 
                 symboling2, data = train)

summary(model_5)
## Multiple R-squared:  0.9765,	Adjusted R-squared:  0.9685 
sort(vif(model_5))

## Removing Companyporsche

model_6 <- lm(formula = price ~ car_ID + aspiration + enginelocation + carwidth + 
                enginesize + stroke + peakrpm + citympg + drivewheelrwd + 
                Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                Companypeugeot + Companyplymouth +  Companyrenault + 
                Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                Companyvolvo + carbodyhardtop + carbodyhatchback +  
                carbodywagon + enginetyperotor +  cylindernumbersix + 
                fuelsystem2bbl + symboling.1 + symboling0 + symboling3 + 
                symboling2, data = train)

summary(model_6)
## Multiple R-squared:  0.9744,	Adjusted R-squared:  0.966
sort(vif(model_6))

## Removing car_id 

model_7 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                enginesize + stroke + peakrpm + citympg + drivewheelrwd + 
                Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                Companypeugeot + Companyplymouth +  Companyrenault + 
                Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                Companyvolvo + carbodyhardtop + carbodyhatchback +  
                carbodywagon + enginetyperotor +  cylindernumbersix + 
                fuelsystem2bbl + symboling.1 + symboling0 + symboling3 + 
                symboling2, data = train)

summary(model_7)
## Multiple R-squared:  0.9726,	Adjusted R-squared:  0.9639 
sort(vif(model_7))

## Removing  drivewheelrwd . Not removing carwidth and enginesize as they have significantly low p values which can be statistically significant , hence not removing these. 

model_8 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                enginesize + stroke + peakrpm + citympg +  
                Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                Companypeugeot + Companyplymouth +  Companyrenault + 
                Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                Companyvolvo + carbodyhardtop + carbodyhatchback +  
                carbodywagon + enginetyperotor +  cylindernumbersix + 
                fuelsystem2bbl + symboling.1 + symboling0 + symboling3 + 
                symboling2, data = train)

summary(model_8)
## Multiple R-squared:  0.9724,	Adjusted R-squared:  0.964
sort(vif(model_8))

## Removing citympg

model_9 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                enginesize + stroke + peakrpm +   
                Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                Companypeugeot + Companyplymouth +  Companyrenault + 
                Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                Companyvolvo + carbodyhardtop + carbodyhatchback +  
                carbodywagon + enginetyperotor +  cylindernumbersix + 
                fuelsystem2bbl + symboling.1 + symboling0 + symboling3 + 
                symboling2, data = train)

summary(model_9)
## Multiple R-squared:  0.9717,	Adjusted R-squared:  0.9635 
sort(vif(model_9))

## Removing fuelsystem2bbl

model_10 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke + peakrpm +   
                 Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo + carbodyhardtop + carbodyhatchback +  
                 carbodywagon + enginetyperotor +  cylindernumbersix + 
                 symboling.1 + symboling0 + symboling3 + 
                 symboling2, data = train)

summary(model_10)
## Multiple R-squared:  0.9705,	Adjusted R-squared:  0.9622 
sort(vif(model_10))

## Removing symboling.1

model_11 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke + peakrpm +   
                 Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo + carbodyhardtop + carbodyhatchback +  
                 carbodywagon + enginetyperotor +  cylindernumbersix + 
                  symboling0 + symboling3 + 
                 symboling2, data = train)

summary(model_11)
## Multiple R-squared:  0.9705,	Adjusted R-squared:  0.9626 
sort(vif(model_11))

## Removing cylindernumbersix

model_12 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                enginesize + stroke + peakrpm +   
                Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                Companypeugeot + Companyplymouth +  Companyrenault + 
                Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                Companyvolvo + carbodyhardtop + carbodyhatchback +  
                carbodywagon + enginetyperotor +   
                symboling0 + symboling3 + 
                symboling2, data = train)

summary(model_12)
## Multiple R-squared:   0.97,	Adjusted R-squared:  0.9623 
sort(vif(model_12))

## Removing symboling2

model_13 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke + peakrpm +   
                 Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo + carbodyhardtop + carbodyhatchback +  
                 carbodywagon + enginetyperotor +   
                 symboling0 + symboling3 , data = train)

summary(model_13)
## Multiple R-squared:  0.9689,	Adjusted R-squared:  0.9612
sort(vif(model_13))


## Removing peak rpm

model_14 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo + carbodyhardtop + carbodyhatchback +  
                 carbodywagon + enginetyperotor +   
                 symboling0 + symboling3 , data = train)

summary(model_14)
## Multiple R-squared:  0.9684,	Adjusted R-squared:  0.9609 
sort(vif(model_14))

## Removing symboling3

model_15 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo + carbodyhardtop + carbodyhatchback +  
                 carbodywagon + enginetyperotor +   
                 symboling0  , data = train)

summary(model_15)
## Multiple R-squared:  0.9679,	Adjusted R-squared:  0.9607
sort(vif(model_15))

## Now for the high VIFs all ps are very low hence start removing higher p values. No need to look at VIFs now. 

## Removing carbodywagon

model_16 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo + carbodyhardtop + carbodyhatchback +  
                 enginetyperotor +   
                 symboling0  , data = train)

summary(model_16)
## Multiple R-squared:  0.9679,	Adjusted R-squared:  0.9611 
## Removing symboling0

model_17 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo + carbodyhardtop + carbodyhatchback +  
                 enginetyperotor  , data = train)

summary(model_17)
## Multiple R-squared:  0.9677,	Adjusted R-squared:  0.9611
## Removing carbodyhardtop

model_18 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo +  carbodyhatchback +  
                 enginetyperotor  , data = train)

summary(model_18)
## Multiple R-squared:  0.967,	Adjusted R-squared:  0.9607 
## Removing carbodyhatchback

model_19 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge + Companyhonda + Companyisuzu + 
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo +    
                 enginetyperotor  , data = train)

summary(model_19)
## Multiple R-squared:  0.9657,	Adjusted R-squared:  0.9594
## Removing Companyisuzu

model_20 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge + Companyhonda +  
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysaab + Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo +    
                 enginetyperotor  , data = train)

summary(model_20)
## Multiple R-squared:  0.9635,	Adjusted R-squared:  0.9572
## Removing Companysaab 

model_21 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge + Companyhonda +  
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo +    
                 enginetyperotor  , data = train)

summary(model_21)
## Multiple R-squared:  0.9613,	Adjusted R-squared:  0.955
## Removing Companyhonda

model_22 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge +   
                 Companymazda + Companymercury + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo +    
                 enginetyperotor  , data = train)

summary(model_22)
## Multiple R-squared:  0.9588,	Adjusted R-squared:  0.9524

## Removing Companymercury

model_23 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge +   
                 Companymazda  + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysubaru + Companytoyota + Companyvolkswagon + 
                 Companyvolvo +    
                 enginetyperotor  , data = train)

summary(model_23)
## Multiple R-squared:  0.9564,	Adjusted R-squared:  0.9501
##  Removing Companyvolvo

model_24 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge +   
                 Companymazda  + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysubaru + Companytoyota + Companyvolkswagon + 
                 enginetyperotor  , data = train)
        
summary(model_24)
## Multiple R-squared:  0.9546,	Adjusted R-squared:  0.9485

## Removing Companyvolkswagon

model_25 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge +   
                 Companymazda  + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +  Companyrenault + 
                 Companysubaru + Companytoyota + 
                 enginetyperotor  , data = train)

summary(model_25)
## Multiple R-squared:  0.9525,	Adjusted R-squared:  0.9465
## Removing Companyrenault

model_26 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge +   
                 Companymazda  + Companymitsubishi + Companynissan + 
                 Companypeugeot + Companyplymouth +   
                 Companysubaru + Companytoyota + 
                 enginetyperotor  , data = train)

summary(model_26)
## Multiple R-squared:  0.9503,	Adjusted R-squared:  0.9444
## Removing Companyplymouth

model_27 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw + Companydodge +   
                 Companymazda  + Companymitsubishi + Companynissan + 
                 Companypeugeot +    
                 Companysubaru + Companytoyota + 
                 enginetyperotor  , data = train)

summary(model_27)
## Multiple R-squared:  0.947,	Adjusted R-squared:  0.9412 
## Removing Companydodge

model_28 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw +    
                 Companymazda  + Companymitsubishi + Companynissan + 
                 Companypeugeot +    
                 Companysubaru + Companytoyota + 
                 enginetyperotor  , data = train)

summary(model_28)
## Multiple R-squared:  0.9445,	Adjusted R-squared:  0.9389
## Removing Companynissan

model_29 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw +    
                 Companymazda  + Companymitsubishi +  
                 Companypeugeot +    
                 Companysubaru + Companytoyota + 
                 enginetyperotor  , data = train)

summary(model_29)
## Multiple R-squared:  0.9413,	Adjusted R-squared:  0.9359
## Removing Companymazda

model_30 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw +    
                  Companymitsubishi +  
                 Companypeugeot +    
                 Companysubaru + Companytoyota + 
                 enginetyperotor  , data = train)

summary(model_30)
## Multiple R-squared:  0.9384,	Adjusted R-squared:  0.9333
## Removing Companymitsubishi

model_31 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw +    
                 Companypeugeot +    
                 Companysubaru + Companytoyota + 
                 enginetyperotor  , data = train)

summary(model_31)
## Multiple R-squared:  0.9345,	Adjusted R-squared:  0.9295 
##Removing Companytoyota

model_32 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw +    
                 Companypeugeot +    
                 Companysubaru + 
                 enginetyperotor  , data = train)

summary(model_32)
## Multiple R-squared:  0.9303,	Adjusted R-squared:  0.9255 
##Removing Companypeugeot 

model_33 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw +    
                 Companysubaru + 
                 enginetyperotor  , data = train)

summary(model_33)
## Multiple R-squared:  0.9255,	Adjusted R-squared:  0.921

## Remove Companysubaru 

model_34 <- lm(formula = price ~  aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw +    
                 enginetyperotor  , data = train)

summary(model_34)
## Multiple R-squared:  0.9195,	Adjusted R-squared:  0.9153
## Here all Ps are low . Now, this model can be considered to predict values on test data. 
# predicting the results in test dataset model 34 
## Used function predict() to get the predicted value of dependant variable i.e. price. 
## The Predicted value is stored in variable test_price and is then added into the test data frame. 

## I  Predictive Model 1 : model_34 as got from above 

Predict_1 <- predict(model_34,test[,-19])
## Storing the value of predicted price in the test dataframe with the column name test_price ; so that actual and predicted prices can be compared. 
test$test_price <- Predict_1

# Now, we need to test the r square between actual and predicted car price. 
## Used function cor() to find the correlation between actual price and predicted price. 
r <- cor(test$price,test$test_price)
## Printed the value to see the value of correlation coefficient i.e. r
r
## Value of r comes out to be 0.920522
## Calcualting R squared as that would give a more accurate measure of correlation.Square of the correlation gives the value of R square. 
rsquared <- cor(test$price,test$test_price)^2
rsquared
## Value of r squared comes out to be 0.84736 which is approx 85 percent. The difference between R square of train and test data is 7% ;hence this cant be best fit model. 
## Hence First Predictive MOdel with good value of R squared is the model_34 as stated above .

## 
## Plots 
## Actual vs. Predicted Proce PLot  for the  Model 34 

ggplot(test, aes(car_ID, price)) + geom_line(aes(colour = "blue" )) + geom_line(aes(x=car_ID, y=test_price, colour="red"))

## Also plotting Error i.e. difference between actual price and predicted price to see if error follows some pattern.
test$error <- test$price-test$test_price
ggplot(test, aes(car_ID, error)) + geom_point() + geom_hline(yintercept = 0)

## No specific pattern followed in the error graph; so model can be good but its not best fit due to more difference in R square of Train and test. 

## II  Predictive Model 2 

## Now Preparing Second Model . Removing the values one by one  based on higher p values among the remaining variables. 
## As we can observe that aspiration has the higher p values amongst the remaining variables. Hence removing aspiration first.  
## Removing variable aspiration first aspiration

model_35 <- lm(formula = price ~  enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw +    
                 enginetyperotor  , data = train)

summary(model_35)
## Multiple R-squared:  0.9121,	Adjusted R-squared:  0.9083 .Now from the summary of this model it can be noticed that after removing Aspiration, Stroke also has a high p value . So removing stroke as well. 
##  Removing stroke

model_36 <- lm(formula = price ~  enginelocation + carwidth + 
                 enginesize +     
                 Companybmw +    
                 enginetyperotor  , data = train)

summary(model_36)
## Multiple R-squared:  0.906,	Adjusted R-squared:  0.9026  
## The removing enginetyperotor

model_37 <- lm(formula = price ~  enginelocation + carwidth + 
                 enginesize +     
                 Companybmw    
                   , data = train)

summary(model_37)
## Multiple R-squared:  0.8958,	Adjusted R-squared:  0.8927  
## We can observe that now all the p values are significantly low.
## Hence this could be another model for Predicting price values. 
## Now Predicting price values based on the model_37 
## predicting the results in test dataset
Predict_2 <- predict(model_37,test[,-19])
test$test_price <- Predict_2

# Now, we need to test the r square between actual and predicted price of car. Using function cor()
r <- cor(test$price,test$test_price)
r
## R value comes out to be 0.9207258
## Now, calculating Adjusted R square 
rsquared <- cor(test$price,test$test_price)^2
rsquared
## Value comes out to be 0.8477 which is also a decent value for R square. 
## So, as per Second Predictive model , the variables on which car price can depend are enginelocation,carwidth ,enginesize,Companybmw.
## Also, the difference between R square of train and test data is 4.5% ; which is very good for a model to be best fit. 

## Plotting the actual price and the predicted price values 

ggplot(test, aes(car_ID, price)) + geom_line(aes(colour = "blue" )) + geom_line(aes(x=car_ID, y=test_price, colour="red"))

## The plots between actual and predicted price overlap very well. Hence this can be a good fit model.  

## Also plotting Error i.e. difference between actual price and predicted price to see if error follows some pattern.
test$error <- test$price-test$test_price
ggplot(test, aes(car_ID, error)) + geom_point() + geom_hline(yintercept = 0)

## The error graph is  random and does not follow any specific pattern; hence the model is good. 

## III Predictive model 3 

## If we observe Model 35, before removing the variable stroke, that can also be considered as final model for predicting values of car price. 
## Based on business understanding  stroke can be an important variable on which car price can depend , So trying building a model with variable stroke and see how good is it. 

model_35 <- lm(formula = price ~  enginelocation + carwidth + 
                 enginesize + stroke +    
                 Companybmw +    
                 enginetyperotor  , data = train)
summary(model_35)
## Multiple R-squared:  0.9121,	Adjusted R-squared:  0.9083 
# predicting the results in test dataset model 35 
Predict_3 <- predict(model_35,test[,-19])

test$test_price <- Predict_3

# Now, we need to test the r square between actual and predicted sales. 

r <- cor(test$price,test$test_price)
r
## Value of R comes out to be 0.9226675
rsquared <- cor(test$price,test$test_price)^2
rsquared
## Value of r square comes out to be 0.8513 

## Difference between Adjusted R square of train and test data is 5.7% which is very high for a model to be best fit . 

## Plotting Actual Price vs. Predicted Price
ggplot(test, aes(car_ID, price)) + geom_line(aes(colour = "blue" )) + geom_line(aes(x=car_ID, y=test_price, colour="red"))

## The plots overlap, but the overlapping was much better for model_37 as can be seen from above.

##Also plotting Error i.e. difference between actual price and predicted price to see if error follows some pattern.
test$error <- test$price-test$test_price
ggplot(test, aes(car_ID, error)) + geom_point() + geom_hline(yintercept = 0)

## The Error plot here is also random , so this model can also be good. 

### IV Predictive model 4 

## Now, we can try building model by removing the company name variable , and see the impact it has on the values of r and adjusted r square. 
## Test  removing companybmw ,aspiration one by one and prepared 2 different models 
## Removing company bmw

model_38 <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                 enginesize + stroke +    
                 enginetyperotor  , data = train)

summary(model_38)
## Multiple R-squared:  0.9046,	Adjusted R-squared:  0.9004

# predicting the results in test dataset model 38 
Predict_4 <- predict(model_38,test[,-19])
test$test_price <- Predict_4

# Now, we need to test the r square between actual and predicted sales. 
r <- cor(test$price,test$test_price)
r
## 0.865024
rsquared <- cor(test$price,test$test_price)^2
rsquared
## R square comes out ot be 0.7482665. This is not a good model as ajusted R square value comes out to be very low for correlation between actual test price and predictive test price. 

## Predictive Model 5 
## Now try Removing  enginelocation to see what impact it has on the model 

model_39 <- lm(formula = price ~  aspiration + carwidth + 
                 enginesize + stroke +    
                 enginetyperotor  , data = train)

summary(model_39)
## Multiple R-squared:  0.8677,	Adjusted R-squared:  0.8629  . Since values of R square and adjusted R square drop by alomst 5 percent to 0.8629 ;so this cant be considered as a good model . 

# predicting the results in test dataset model 38 
Predict_5 <- predict(model_39,test[,-19])
test$test_price <- Predict_5

# Now, we need to test the r square between actual and predicted sales. 
r <- cor(test$price,test$test_price)
r
##  0.8513162
rsquared <- cor(test$price,test$test_price)^2
rsquared
## R square comes out ot be  0.72473927. Since R squared comes to be very low, so this is not a good model. 

## Conclusion : 

## Below is a summary of all the Predictive models along with the values of Adjusted R square of Train and correlation between Actual Car Price and Predicted Car price

## Predictive Model        Independent Variables on which Price depends        Adjusted R square of Correlation between
##                                                                                 Actual Car Proce and Predicted Car Price    Adjusted R square of Train data
##        1                  Aspiration,enginelocation,carwidth,enginesize
##                               stroke,Companybmw,enginetyperotor                   0.8473608                                  0.9153
##
##        2                  enginelocation,carwidth,enginesize,Companybmw           0.8477359                                   0.8927
##
##        3                  enginelocation,carwidth,enginesize,stroke,Companybmw,   0.8513                                     0.9083
##                                     enginetyperotor
## 
##        4                   aspiration,enginelocation,carwidth,enginesize,stroke   0.7482665                                  0.9004
##                                     ,enginetyperotor
## 
## 
##        5                   aspiration,carwidth,enginesize,stroke,                 0.7247392                                 0.8629
##                                       enginetyperotor
## -----------------------------------------------------------------------------------------------------------------------
## 
## 
## As can be seen from above graphs and R values , Predictive models 1,2,3 are fairly good,
##  but the best fit model id Predictive model 2 i.e. model number 37. 
## 
## Now Based on the values of Adjusted R square of the Train Dataset and R squared value of correlation between actual and predicted price. 
## Also the difference between  R square of test and train  is minimum for predictive model 2 i.e. Model number 37 which is 4.5%.
## Also when Actual Price and Predicted price were plotted it was quite overlapping and the error plot also showed randomness. 
##
##
## We can conclude that MOdel 37  is the best fit model for predicting car price. 
## Below is a summary of the best fit model 
## 
## Residuals:
##Min      1Q  Median      3Q     Max 
##-5757.3 -1759.7     3.1  1421.9  7151.4 

##Coefficients:
## Estimate Std. Error t value Pr(>|t|)    
##(Intercept)    -79942.860   9943.118  -8.040 3.63e-13 ***
## enginelocation -16431.882   1744.223  -9.421  < 2e-16 ***
## carwidth         1464.582    172.539   8.488 2.94e-14 ***
##  enginesize         99.346      9.338  10.638  < 2e-16 ***
##  Companybmw       7533.448   1578.182   4.773 4.56e-06 ***
##  ---
  ##  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

##Residual standard error: 2676 on 138 degrees of freedom
##Multiple R-squared:  0.8958,	Adjusted R-squared:  0.8927 
##F-statistic: 296.5 on 4 and 138 DF,  p-value: < 2.2e-16
## 
## Hence Price Depends on these 4 variables :
##      
##      1. Enginelocation
##      2. carwidth
##      3. enginesize
##      4. Companybmw
##      
##
## Showing the predictive values for the best fit model i.e Model_37 again
Predict_2 <- predict(model_37,test[,-19])
## Storing the value of predicted price in the test dataframe with the column name test_price ; so that actual and predicted prices can be compared. 
test$test_price <- Predict_2

# Now, we need to test the r square between actual and predicted car price. 
## Used function cor() to find the correlation between actual price and predicted price. 
r <- cor(test$price,test$test_price)
## Printed the value to see the value of correlation coefficient i.e. r
r
## Value of r comes out to be 0.9207258
## Calcualting R squared as that would give a more accurate measure of correlation.Square of the correlation gives the value of R square. 
rsquared <- cor(test$price,test$test_price)^2
rsquared

## R squared value of test data comes out ot be 0.8477359 i.e. 84.8%

## Also difference between R square value of Test and Train data is least of all the possible good models i.e. 4.5% which also makes it the best fit model. 
## Plots 


## Actual vs. Predicted Proce PLot  for the final best fit model i.e. Model 37 

ggplot(test, aes(car_ID, price)) + geom_line(aes(colour = "blue" )) + geom_line(aes(x=car_ID, y=test_price, colour="red"))

## Red line shows the predicted values and Blue shows the actual price values. 
## We can see that the graphs for actual and predicted prices are quite overlapping , hence it seems to be the best fit  model. 

## Also plotting Error i.e. difference between actual price and predicted price to see if error follows some pattern.
test$error <- test$price-test$test_price
ggplot(test, aes(car_ID, error)) + geom_point() + geom_hline(yintercept = 0)

## No specific pattern followed in the error graph; hence erros are random and model is good and also the best fit.  