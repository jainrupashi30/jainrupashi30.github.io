## Module - Group Project - Time Series Case Study
## Name - Preksha,Rupashi,Rajshree
## Instructions - Set the working directory path and place the data file(Global Superstore.csv) in same path 
# Remove existing memory space if any
remove(list=ls())
suppressWarnings(library(RODBC))

## read.csv() function is used to read given csv file into a data frame named global_superstore.
## Argument-stringAsFactor is set as False so strings in a data frame is treated as just string not as a factor. 
global_superstore <- read.csv("Global Superstore.csv",stringsAsFactors = F)

## Install the required packages and Load the libraries
#install.packages("forecast")
#install.packages("tseries")
#install.packages("ggplot2")
#install.packages("lubridate")
#install.packages("tidyr")
#install.packages("dplyr")
library(lubridate)
library(dplyr)
library(tidyr)
library(forecast)
library(tseries)
require(graphics)
library(ggplot2)

######################### Data Understanding and Data Cleaning #####################################
#1.1) Data frame has 51290 observations and 24 variables. dim() function returns he number of observations and variables. 
dim(global_superstore) 
## names() function returns the variable names of the dataframe. 
names(global_superstore)
## str() function helps understand the structure of the dataframe as to which  variable has what datatype and displays first few value of the variable.
str(global_superstore)
## head() function returns first few values of all the variables of the data frame. 
head(global_superstore)
#1.2) Checked for NA values and removed from dataset using sum(is.na) and subset functions  
sapply(global_superstore, function(x) sum(is.na(x)))
#State        Country    Postal.Code         Market         Region 
#0              0          41296              0              0 
# we have total 51290 observations out of which total count of NA's value for the variable Postal Code is 41296 . 
# So,best is to remove this variable from dataframe  
superstore <- subset(global_superstore,select = -Postal.Code)
# 1.3) Checked for duplicate values and removed if any using duplicated() function
sum(duplicated(superstore)) # no duplicates founds

########################## Data Manupilation #################################################
#2.1) Convert Order.Date and Ship.Date into date cols parse_date_time() is used for the same . 
superstore$Order.Date <- parse_date_time(superstore$Order.Date,orders = "%d%m%Y")
superstore$Ship.Date <- parse_date_time(superstore$Ship.Date,orders = "%d%m%Y")
# Summary of order date using the function summary() : it would dispaly min,max ,mean,median etc. 
summary(superstore$Order.Date)
# we have transaction data from Jan'2011 to Dec'2014

############################ Data Preparation  ##############################################
#3.1) Created segments of total profit, total sales and profit percentage based on based on Market and Customer-Segments.
## aggregate() is used to perform aggregate functions on the specified columns . The values given to the by= parameter are the ones on which grouping needs to be performed.
## names() is used to assign names to the columns of the specified data frame. 
profit_tot<-aggregate(superstore$Profit, by=list(superstore$Market,superstore$Segment), FUN=sum)
names(profit_tot)<-list("Market","Segment","Total.Profit")
## Calculating Total Sales
sales_tot<-aggregate(superstore$Sales, by=list(superstore$Market,superstore$Segment), FUN=sum)
names(sales_tot)<-list("Market","Segment","Total.Sales")
## Calculating Total Quantity
Quantity_tot<-aggregate(superstore$Quantity, by=list(superstore$Market,superstore$Segment), FUN=sum)
names(Quantity_tot)<-list("Market","Segment","Total.Quantity")
segments_total <- data.frame(profit_tot,sales_tot,Quantity_tot)
## Creating Data frame containing all the totals along with Market and Segments . 
segments_total <- segments_total[,c(1,2,3,6,9)]
## Calculating Profit percent as the ratio of Total Profit to Total Sales to get a more accurate relative value of profit .
segments_total$Profit.Percent <- (segments_total$Total.Profit/segments_total$Total.Sales)*100
#3.3) Monthly Analysis of total profit,total sales & total quantity on the basis of market-segment
## Formatting the Order date column in month and year format. format() function is used to acheive that. 
superstore$Order.Year_Month <- format(superstore$Order.Date,"%b%Y")
## Calculating Monthly Total Profit for each market-segment group. 
monthly_Sum_profit <- aggregate(superstore$Profit, by=list(superstore$Market,superstore$Segment,superstore$Order.Year_Month), FUN=sum)
names(monthly_Sum_profit)<-list("Market","Segment","Month","Monthly.TotalProfit")
## Calculating Monthly Total Sales for each market-segment group. 
monthly_Sum_sales <- aggregate(superstore$Sales, by=list(superstore$Market,superstore$Segment,superstore$Order.Year_Month), FUN=sum)
names(monthly_Sum_sales)<-list("Market","Segment","Month","Monthly.Totalsales")
## Calculating Monthly Total Quantity for each market-segment group.
monthly_Sum_Quantity <- aggregate(superstore$Quantity, by=list(superstore$Market,superstore$Segment,superstore$Order.Year_Month), FUN=sum)
names(monthly_Sum_Quantity)<-list("Market","Segment","Month","Monthly.TotalQuantity")
#3.4)Derived monthly profit percentage from Monthly totalprofit and totalsale
## created a dataframe to store all the monthly totals . data.frame() is used to store all the input values in form of a data frame. 
segments_monthly_total <- data.frame(monthly_Sum_profit,monthly_Sum_sales,monthly_Sum_Quantity)
segments_monthly_total <- segments_monthly_total[,c(1,2,3,4,8,12)]
## Calculating Monthly Profit percent as the ratio of Total Profit to Total Sales to get a more accurate relative value of profit .
segments_monthly_total$Monthly.ProfitPercent <- (segments_monthly_total$Monthly.TotalProfit/segments_monthly_total$Monthly.Totalsales)*100
#3.5) Derived CV (coefficient of variation) from Profit Mean and Profit SD. It is given by deviding SD to Mean. Any value <1 would signify that all the values are uniformly distributed and no none of them is an outlier. 
MonthlyAvgProfitPercent <- aggregate(segments_monthly_total$Monthly.ProfitPercent, by=list(segments_monthly_total$Market,segments_monthly_total$Segment), FUN=mean)
names(MonthlyAvgProfitPercent)<-list("Market","Segment","Monthly.AvgProfitPercent")
MonthlySDProfitPercent <- aggregate(segments_monthly_total$Monthly.ProfitPercent, by=list(segments_monthly_total$Market,segments_monthly_total$Segment), FUN=sd)
names(MonthlySDProfitPercent)<-list("Market","Segment","Monthly.SDProfitPercent")
segments_total_final <- data.frame(segments_total,MonthlyAvgProfitPercent,MonthlySDProfitPercent)
segments_total_final <- segments_total_final[,c(-7,-8,-10,-11)]
## Deriving CV 
segments_total_final$CV <- (segments_total_final$Monthly.SDProfitPercent/segments_total_final$Monthly.AvgProfitPercent)
## Ordering by Total Profit to get the most profitable market segmet combo . 
segments_total_final<-segments_total_final[order(segments_total_final$Total.Profit,decreasing=TRUE),]
## Top 2 Market and Segment based on High Profit and low CV values  : 
## Market Segment  Total_Profit Total_Sales Total_Quantity Mean_Profit SD_Profit  CV_Value
##  APAC  Consumer     222817.6   1816753.7         21414    11.88496  4.822884 0.4057972
##    EU  Consumer     188687.7   1529716.2         19541    11.78485  8.380616 0.7111344

############################ Exploratory Data Analysis ######################################
# 4.1)  Market-segment wise total profit trend 
ggplot(data=segments_total_final, aes(x=Market, y=Total.Profit, fill=Segment)) + geom_bar(stat="identity") +
 labs(x="Market",y="Total Profit",title="Total Profit trends based on Market-segment")
# Graph shows that APAC-Cosumer and EU-Consumer are the top 2 players.
# 4.2) Market-segemnt wise CV trends
ggplot(data=segments_total_final, aes(x=Market, y=CV, fill=Segment)) + geom_bar(stat="identity") +
  labs(x="Market",y="CV",title="Market-segment wise CV trends")
# Graph shows that APAC consumer and EU consumer having the low CVs which signify that the profits are consistent throughout with no outliers. 
# 4.3) Market-Segment wise Total sale,Total quantity and Total trend
boxplot(segments_total_final$Total.Sales~segments_total_final$Market)
boxplot(segments_total_final$Total.Quantity~segments_total_final$Market)
boxplot(segments_total_final$Total.Profit~segments_total_final$Market)
# Graph shows that there are no outliers present in data; hence no outlier treatment is required. 

############################    Data Manipulation for data modelling and forecasting   #####################################################
#5.1) Filter data based on Top 2 Market and Customer-segment i.e. APAC Consumer and EU Consumer. 
##filter() function is used to acheive the same. 
final_Segment_APAC <- filter(segments_monthly_total,segments_monthly_total$Market=="APAC",segments_monthly_total$Segment=="Consumer")
final_Segment_EU <- filter(segments_monthly_total,segments_monthly_total$Market=="EU",segments_monthly_total$Segment=="Consumer")
## Converting to proper date format . 
final_Segment_APAC$Month <- parse_date_time(final_Segment_APAC$Month,"%b-%Y")

## Sorting as per the month and year. 
final_Segment_APAC<-final_Segment_APAC[order(as.Date(final_Segment_APAC$Month,format= "%b-%Y")),]
## Performing the same steps for EU as well. 
final_Segment_EU$Month <- parse_date_time(final_Segment_EU$Month,"%b-%Y")
final_Segment_EU<-final_Segment_EU[order(as.Date(final_Segment_EU$Month,format= "%b-%Y")),]

#5.2) Added a new column "No_of_months" . This column contains the value of the number of months passed from minimum i.e. Jan-2011 till the present month of each row. 
## This column is needed in order to perform limfit() for model building and forecasting. 

final_Segment_APAC$No_of_months <- c(1:nrow(final_Segment_APAC))
final_Segment_EU$No_of_months <- c(1:nrow(final_Segment_EU))

## ************************** Forcasting for APAC Consumer -Sales ***************************************************************
#6.1) Time series 
## ts() is used to build time series for the specified column 
APAC_sales_TotalTS <- ts(final_Segment_APAC$Monthly.Totalsales)
## Considering the data except for last 6 months for building the model 
APAC_sales_indata <- final_Segment_APAC[1:42,]

## Building time series for the in data for the model building. 
APAC_sales_TS <- ts(APAC_sales_indata$Monthly.Totalsales)

## PLotting the time series. 
plot(APAC_sales_TS)

#6.2) Smoothing the series using holtwinter method 
cols <- c("red", "blue", "green", "black")
alphas <- c(0.02, 0.1, 0.8)
labels <- c(paste("alpha =", alphas), "Original")
for (i in seq(1,length(alphas))) {
  smoothedseries_sales_EU <- HoltWinters(APAC_sales_TS, alpha=alphas[i],
                                       beta=FALSE, gamma=FALSE)
  lines(fitted(smoothedseries_sales_EU)[,1], col=cols[i], lwd=2)
}
legend("bottomleft", labels, col=cols, lwd=2)

## It was observed from the graph that only alpha value 0.1 seems to be a better smotthing when compared to others. alpha 0.8 tends to overfit the data and doesnt seem to smoothen it . 
##Alpha 0.02 is not a good fit for the original time series. 

## Using Moving average method to see if it can smoothen the series better. 

#6.3) Smoothing the series using Weighted Moving Average Smoothing method.
w <-1
APAC_sales_smseries<- stats::filter(APAC_sales_TS, filter=rep(1/(2*w+1),(2*w+1)), 
                                    method='convolution', sides=2)
#Smoothing left end of the time series
diff <- APAC_sales_smseries[w+2] - APAC_sales_smseries[w+1]
for (i in seq(w,1,-1)) {
  APAC_sales_smseries[i] <- APAC_sales_smseries[i+1] - diff
}
#Smoothing right end of the time series
n <- length(APAC_sales_TS)
diff <- APAC_sales_smseries[n-w] - APAC_sales_smseries[n-w-1]
for (i in seq(n-w+1, n)) {
  APAC_sales_smseries[i] <- APAC_sales_smseries[i-1] + diff
}
#6.4) Plot the smoothed time series
APAC_sales_timesvals <- APAC_sales_indata$No_of_months
lines(APAC_sales_smseries, col="blue", lwd=2)
## The plot shows the smoothed series shwos similar patterns to the original time series and is much better than the holt winters smoothing; 
## Hence moved ahead with the Weighted Moving Average Smoothing method.  

# Below table shows summary for different attiritons tried before reaching optimal 
# values for the coefficients of sin , cos , poly for lmfit() and window size (w) to build the best forcasting model.
## The best one is the one with minimum MAPE and has been used further in this code. 
#------------------------|----------------------|-----------------------------| 
# Parameters(APAC Sales) |    Attrition1        |      Attrition 2            |
#------------------------|----------------------|-----------------------------|
#  Window                |    1                 |    3                        |
#  Sin/Cos Coefficient   |    0.5               |    0.8                      |
#  Poly                  |    3                 |    3                        |
#  Model                 | Classical | AutoArima| Classical Deco | AutoArima  |
#  Model Fit             | (0,0,0)   | (0,1,1)  |   (0,0,0)      | (0,1,1)    |
#  Sigma                 | 8.8e+07   | 198150751|   123311900    |  198150751 |
#  LogLikelihood         | -443.75   | -515.41  |   -450.37      | -515.41    |
#  AIC                   | 889.49    | 1034.83  |   903.74       |  1034.83   |
#  AICc                  | 889.59    | 1035.1   |   903.84       |  1035.1    |
#  BIC                   | 891.23    | 1038.53  |   905.48       |  1038.53   |
#  MAPE                  | 31.07429  | 28.06045 |   41.94541     |  28.06045  |
#-----------------------------------------------------------------------------|
#################### classical decomposition for APAC Consumer -Sales ###########################################

# 6.5) First, let's convert the time series to a dataframe

APAC_sales_smootheddf <- as.data.frame(cbind(APAC_sales_timesvals, as.vector(APAC_sales_smseries)))
colnames(APAC_sales_smootheddf) <- c('Month', 'Sales')

#Now, let's fit a multiplicative model with trend and seasonality to the data
APAC_sales_lmfit <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
                       + Month, data=APAC_sales_smootheddf)
summary(APAC_sales_lmfit)
accuracy(APAC_sales_lmfit)
## Predicting values using the lmfit model. used function predict() here. 
APAC_sales_global_pred <- predict(APAC_sales_lmfit, Month=APAC_sales_timesvals)
summary(APAC_sales_global_pred)
## Plotting graph for the predicted values along with the actual values. 
lines(APAC_sales_timesvals, APAC_sales_global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series.
## Subtracting the predicted values from the total to get the  the local predictable values. 
APAC_sales_local_pred <- APAC_sales_TS-APAC_sales_global_pred
plot(APAC_sales_local_pred, col='red', type = "l")
acf(APAC_sales_local_pred)
acf(APAC_sales_local_pred, type="partial")
## Performong auto.arima to remove any predictable parts from the time series. 
APAC_sales_armafit <- auto.arima(APAC_sales_local_pred)
tsdiag(APAC_sales_armafit)
## The graph shows the ACF residuals fall mostly close to zero value for all the non 0 lags ; hence it resembles white noise. 
## The pacf graph shows a sinusoidal trend which is also a characterisitic of white noise. 
APAC_sales_armafit
### sigma^2 estimated as 8.8e+07:  log likelihood=-443.75
### AIC=889.49   AICc=889.59   BIC=891.23

#We'll check if the residual series is white noise
APAC_sales_resi <- APAC_sales_local_pred-fitted(APAC_sales_armafit)
adf.test(APAC_sales_resi,alternative = "stationary")
kpss.test(APAC_sales_resi)
#Dickey-Fuller = -6.8673, Lag order = 3, p-value = 0.01 : Hence can reject null hypothesis  
#KPSS Level = 0.042348, Truncation lag parameter = 3, p-value = 0.1 : Hence can not reject null hypothesis . 
## Both the conditions tell that the series is Stationaryand hence is white noise. 

#Now, let's evaluate the model using MAPE First, let's make a prediction for the last 6 months
APAC_sales_outdata <- final_Segment_APAC[43:48,]
APAC_sales_timevals_out <- APAC_sales_outdata$No_of_months
## predict() is used to predict values for the out data i.e. next 6 months here  based on the model built above. 
APAC_sales_global_pred_out <- predict(APAC_sales_lmfit,data.frame(Month =APAC_sales_timevals_out))
APAC_sales_fcast <- APAC_sales_global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE 
APAC_sales_MAPE <- accuracy(APAC_sales_fcast,APAC_sales_outdata[,5])[5]
APAC_sales_MAPE 
#[1] 31.07429

#Let's also plot the predictions along with original values, to get a visual feel of the fit
class_dec_pred <- c(ts(APAC_sales_global_pred),ts(APAC_sales_global_pred_out))
plot(APAC_sales_TotalTS, col = "black")
lines(class_dec_pred, col = "red")

######################## ARIMA fit for APAC-Sales ####################################################
## auto.arima() is used to automatically build a model for forecasting the time series. 
APAC_sales_autoarima<- auto.arima(APAC_sales_TotalTS)
APAC_sales_autoarima
tsdiag(APAC_sales_autoarima)
plot(APAC_sales_autoarima$x, col="black")
lines(fitted(APAC_sales_autoarima), col="red")

#Again, let's check if the residual series is white noise
APAC_sales_resi_AA <- APAC_sales_TotalTS - fitted(APAC_sales_autoarima)
adf.test(APAC_sales_resi_AA,alternative = "stationary")
kpss.test(APAC_sales_resi_AA)
#Dickey-Fuller = -4.4927, Lag order = 3, p-value = 0.01
#KPSS Level = 0.06271, Truncation lag parameter = 3, p-value = 0.1

## As per both the values ; the remainder is white noise. 

#Also, let's evaluate the model using MAPE
APAC_sales_fcast_AA <- predict(APAC_sales_autoarima, n.ahead = 6)
APAC_sales_MAPE_AA <- accuracy(APAC_sales_fcast_AA$pred,APAC_sales_outdata[,5])[5]
APAC_sales_MAPE_AA 
# [1] 28.06045
## Since MAPE value is less than that which was acheived for classical decompositon ; hence ARIMA is preferred over the decomposition model. 
## Hence; showing the finally predicted values below. 

#Lastly, let's plot the predictions along with original values, to get a visual feel of the fit
APAC_sales_AA_pred <- c(fitted(APAC_sales_autoarima),ts(APAC_sales_fcast_AA$pred))
plot(APAC_sales_TotalTS, col = "black")
lines(APAC_sales_AA_pred, col = "red")

##################   Forcasting for APAC-Quantity #########################################

#7.1) Time series for Market APAC and field quantity
APAC_quant_TotalTS <- ts(final_Segment_APAC$Monthly.TotalQuantity)
APAC_quant_indata <- final_Segment_APAC[1:42,]
APAC_quant_TS <- ts(APAC_quant_indata$Monthly.TotalQuantity)
plot(APAC_quant_TS)

#7.2) Smoothing the series using holtwinter method 
cols <- c("red", "blue", "green", "black")
alphas <- c(0.02, 0.1, 0.8)
labels <- c(paste("alpha =", alphas), "Original")
for (i in seq(1,length(alphas))) {
  smoothedseries_Qun_APAC <- HoltWinters(APAC_quant_TS, alpha=alphas[i],
                                beta=FALSE, gamma=FALSE)
  
  lines(fitted(smoothedseries_Qun_APAC)[,1], col=cols[i], lwd=2)
}

legend("bottomleft", labels, col=cols, lwd=2)

#7.3) Smoothing the series using Moving average method
w<-1
APAC_quant_smseries<- stats::filter(APAC_quant_TS, filter=rep(1/(2*w+1),(2*w+1)), 
                                    method='convolution', sides=2)

#Smoothing left end of the time series
diff <- APAC_quant_smseries[w+2] - APAC_quant_smseries[w+1]
for (i in seq(w,1,-1)) {
  APAC_quant_smseries[i] <- APAC_quant_smseries[i+1] - diff
}

#Smoothing right end of the time series
n <- length(APAC_quant_TS)
diff <- APAC_quant_smseries[n-w] - APAC_quant_smseries[n-w-1]
for (i in seq(n-w+1, n)) {
  APAC_quant_smseries[i] <- APAC_quant_smseries[i-1] + diff
}
#Plot the smoothed time series
APAC_quant_timesvals <- APAC_quant_indata$No_of_months
lines(APAC_quant_smseries, col="blue", lwd=2)

## Using weigthed average to get the smoothed series as it gives a better fit as explained  above earlier in the code. 

## Summary of all the hit and trials before acheiving the final values which 
## are considered for model building here . 
#------------------------|----------------------|-----------------------------| 
# Parameters(APAC Quant) |    Attrition1        |      Attrition 2            |
#------------------------|----------------------|-----------------------------|
#  Window                |    1                 |    3                        |
#  Sin/Cos Coefficient   |    0.5               |    0.8                      |
#  Poly                  |    3                 |    3                        |
#  Model                 | Classical | AutoArima| Classical Deco | AutoArima  |
#  Model Fit             | (0,0,0)   | (0,1,1)  |   (0,0,0)      | (0,1,1)    |
#  Sigma                 | 10337     | 24377    |   15551        |  24377     |
#  LogLikelihood         | -253.75   | -303.76  |   -262.29      | -303.76    |
#  AIC                   | 509.42    | 611.53   |   526.57       |  611.53    |
#  AICc                  | 509.59    | 611.8    |   526.67       |  611.8     |
#  BIC                   | 511.23    | 615.23   |   528.31       |  615.23    |
#  MAPE                  | 62.10289  | 25.42447 |   46.60981     |  25.42447  |
#-----------------------------------------------------------------------------|

#################### classical decomposition for APAC-Quantity ###########################################

#7.5) First, let's convert the time series to a dataframe
APAC_quant_smootheddf <- as.data.frame(cbind(APAC_quant_timesvals , as.vector(APAC_quant_smseries)))
colnames(APAC_quant_smootheddf) <- c('Month', 'Quantity')
#Now, let's fit a multiplicative model with trend and seasonality to the data
APAC_quant_lmfit <- lm(Quantity ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
                       + Month, data=APAC_quant_smootheddf)
summary(APAC_quant_lmfit)
accuracy(APAC_quant_lmfit)
APAC_quant_global_pred <- predict(APAC_quant_lmfit, Month=APAC_quant_timesvals )
summary(APAC_quant_global_pred )
lines(APAC_quant_timesvals, APAC_quant_global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series We will model it as an ARIMA series
APAC_quant_local_pred <- APAC_quant_TS-APAC_quant_global_pred
plot(APAC_quant_local_pred , col='red', type = "l")
acf(APAC_quant_local_pred)
acf(APAC_quant_local_pred, type="partial")
APAC_quant_armafit <- auto.arima(APAC_quant_local_pred )
tsdiag(APAC_quant_armafit)
APAC_quant_armafit
### sigma^2 estimated as 8.8e+07:  log likelihood=-443.75
### AIC=889.49   AICc=889.59   BIC=891.23

#We'll check if the residual series is white noise
APAC_quant_resi <- APAC_quant_local_pred -fitted(APAC_quant_armafit)
adf.test(APAC_quant_resi,alternative = "stationary")
kpss.test(APAC_quant_resi)
#Dickey-Fuller = -6.8673, Lag order = 3, p-value = 0.01
#KPSS Level = 0.042348, Truncation lag parameter = 3, p-value = 0.1

#Now, let's evaluate the model using MAPE First, let's make a prediction for the last 6 months
APAC_quant_outdata <- final_Segment_APAC[43:48,]
APAC_quant_timevals_out <- APAC_quant_outdata$No_of_months
APAC_quant_global_pred_out <- predict(APAC_quant_lmfit,data.frame(Month =APAC_quant_timevals_out))
APAC_quant_fcast <- APAC_quant_global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE
APAC_quant_MAPE <- accuracy(APAC_quant_fcast ,APAC_quant_outdata[,6])[5]
APAC_quant_MAPE 
#[1] 62.10289

#Let's also plot the predictions along with original values, toget a visual feel of the fit

class_dec_pred <- c(ts(APAC_quant_global_pred),ts(APAC_quant_global_pred_out))
plot(APAC_quant_TotalTS, col = "black")
lines(class_dec_pred, col = "red")

######################## ARIMA fit for APAC-Quantity ####################################################

APAC_quant_autoarima<- auto.arima(APAC_quant_TotalTS)
APAC_quant_autoarima
tsdiag(APAC_quant_autoarima)
plot(APAC_quant_autoarima$x, col="black")
lines(fitted(APAC_quant_autoarima), col="red")

#Again, let's check if the residual series is white noise
APAC_quant_resi_AA <- APAC_quant_TotalTS - fitted(APAC_quant_autoarima)
adf.test(APAC_quant_resi_AA,alternative = "stationary")
kpss.test(APAC_quant_resi_AA)
#Dickey-Fuller = -4.4927, Lag order = 3, p-value = 0.01
#KPSS Level = 0.06271, Truncation lag parameter = 3, p-value = 0.1

#Also, let's evaluate the model using MAPE
APAC_quant_fcast_AA <- predict(APAC_quant_autoarima, n.ahead = 6)
APAC_quant_MAPE_AA <- accuracy(APAC_quant_fcast_AA$pred,APAC_quant_outdata[,6])[5]
APAC_quant_MAPE_AA 
# [1] 25.42447

## Since MAPE value is less than that which was acheived for classical decompositon ; hence ARIMA is preferred over the decomposition model. 
## Hence; showing the finally predicted values below. 
#Lastly, let's plot the predictions along with original values, to get a visual feel of the fit
APAC_quant_AA_pred <- c(fitted(APAC_quant_autoarima),ts(APAC_quant_fcast_AA$pred))
plot(APAC_quant_TotalTS, col = "black")
lines(APAC_quant_AA_pred, col = "red")

##################   Forcasting for EU Consumer -Sales #########################################

#8.1) Time series for Market EU-Quantity
EU_sales_TotalTS <- ts(final_Segment_EU$Monthly.Totalsales)
EU_sales_indata <- final_Segment_EU[1:42,]
EU_sales_TS <- ts(EU_sales_indata$Monthly.Totalsales)
plot(EU_sales_TS)

#8.2) Smoothing the series using holtwinter method 
cols <- c("red", "blue", "green", "black")
alphas <- c(0.02, 0.1, 0.8)
labels <- c(paste("alpha =", alphas), "Original")
for (i in seq(1,length(alphas))) {
  smoothedseries_Qun_EU <- HoltWinters(EU_sales_TS, alpha=alphas[i],
                                       beta=FALSE, gamma=FALSE)
  
  lines(fitted(smoothedseries_Qun_EU)[,1], col=cols[i], lwd=2)
}
legend("bottomleft", labels, col=cols, lwd=2)

#8.3) Smoothing the series using moving Avg method
w <-1
EU_sales_smseries<- stats::filter(EU_sales_TS, filter=rep(1/(2*w+1),(2*w+1)), 
                                  method='convolution', sides=2)

#Smoothing left end of the time series
diff <- EU_sales_smseries[w+2] - EU_sales_smseries[w+1]
for (i in seq(w,1,-1)) {
  EU_sales_smseries[i] <- EU_sales_smseries[i+1] - diff
}
#Smoothing right end of the time series
n <- length(EU_sales_TS)
diff <- EU_sales_smseries[n-w] - EU_sales_smseries[n-w-1]
for (i in seq(n-w+1, n)) {
  EU_sales_smseries[i] <- EU_sales_smseries[i-1] + diff
}
#8.3) Plot the smoothed time series
EU_sales_timesvals <- EU_sales_indata$No_of_months
lines(EU_sales_smseries, col="blue", lwd=2)

# Below table shows summary for different coefficients and window size to get the best forcast
#------------------------|----------------------|-----------------------------| 
# Parameters(EU Sales)   |    Attrition1        |      Attrition 2            |
#------------------------|----------------------|-----------------------------|
#  Window                |    1                 |    4                        |
#  Sin/Cos Coefficient   |    0.5               |    0.8                      |
#  Poly                  |    3                 |    3                        |
#  Model                 | Classical | AutoArima| Classical Deco | AutoArima  |
#  Model Fit             | (0,0,0)   | (2,1,0)  |   (0,0,0)      | (2,1,0)    |
#  Sigma                 | 92551568  | 1.78e+08 |   127188020    |  1.78e+08  |
#  LogLikelihood         | -444.8    | -512.5   |   -451.48      | -512.5     |
#  AIC                   | 891.61    | 1031     |   904.96       |  1031      |
#  AICc                  | 891.71    | 1031.56  |   905.06       |  1031.56   |
#  BIC                   | 893.35    | 1036.55  |   906.7        |  1036.55   |
#  MAPE                  | 92.95788  | 25.28525 |   27.84181     |  25.42447  |
#-----------------------------------------------------------------------------|

#################### classical decomposition for EU-Sales ###########################################

#8.4) First, let's convert the time series to a dataframe

EU_sales_smootheddf <- as.data.frame(cbind(EU_sales_timesvals, as.vector(EU_sales_smseries)))
colnames(EU_sales_smootheddf) <- c('Month', 'Sales')
#Now, let's fit a multiplicative model with trend and seasonality to the data
EU_sales_lmfit <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
                     + Month, data=EU_sales_smootheddf)
summary(EU_sales_lmfit)
accuracy(EU_sales_lmfit)
EU_sales_global_pred <- predict(EU_sales_lmfit, Month=EU_sales_timesvals)
summary(EU_sales_global_pred)
lines(EU_sales_timesvals, EU_sales_global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series We will model it as an ARMA series
EU_sales_local_pred <- EU_sales_TS-EU_sales_global_pred
plot(EU_sales_local_pred, col='red', type = "l")
acf(EU_sales_local_pred)
acf(EU_sales_local_pred, type="partial")
EU_sales_armafit <- auto.arima(EU_sales_local_pred)
tsdiag(EU_sales_armafit)
EU_sales_armafit
### sigma^2 estimated as 8.8e+07:  log likelihood=-443.75
### AIC=889.49   AICc=889.59   BIC=891.23

#We'll check if the residual series is white noise
EU_sales_resi <- EU_sales_local_pred-fitted(EU_sales_armafit)
adf.test(EU_sales_resi,alternative = "stationary")
kpss.test(EU_sales_resi)
#Dickey-Fuller = -6.8673, Lag order = 3, p-value = 0.01
#KPSS Level = 0.042348,Truncation lag parameter = 3, p-value = 0.1

#Now, let's evaluate the model using MAPE First, let's make a prediction for the last 6 months
EU_sales_outdata <- final_Segment_EU[43:48,]
EU_sales_timevals_out <- EU_sales_outdata$No_of_months
EU_sales_global_pred_out <- predict(EU_sales_lmfit,data.frame(Month =EU_sales_timevals_out))
EU_sales_fcast <- EU_sales_global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE
EU_sales_MAPE <- accuracy(EU_sales_fcast,EU_sales_outdata[,5])[5]
EU_sales_MAPE 
#[1] 27.59771

#Let's also plot the predictions along with original values, toget a visual feel of the fit
class_dec_pred <- c(ts(EU_sales_global_pred),ts(EU_sales_global_pred_out))
plot(EU_sales_TotalTS, col = "black")
lines(class_dec_pred, col = "red")

######################## ARIMA fit for EU-Sales ####################################################
EU_sales_autoarima<- auto.arima(EU_sales_TotalTS)
EU_sales_autoarima
tsdiag(EU_sales_autoarima)
plot(EU_sales_autoarima$x, col="black")
lines(fitted(EU_sales_autoarima), col="red")

#Again, let's check if the residual series is white noise
EU_sales_resi_AA <- EU_sales_TotalTS - fitted(EU_sales_autoarima)
adf.test(EU_sales_resi_AA,alternative = "stationary")
kpss.test(EU_sales_resi_AA)
#Dickey-Fuller = -4.4927, Lag order = 3, p-value = 0.01
#KPSS Level = 0.06271, Truncation lag parameter = 3, p-value = 0.1

#Also, let's evaluate the model using MAPE
EU_sales_fcast_AA <- predict(EU_sales_autoarima, n.ahead = 6)
EU_sales_MAPE_AA <- accuracy(EU_sales_fcast_AA$pred,EU_sales_outdata[,5])[5]
EU_sales_MAPE_AA 
# [1] 25.28

## Since MAPE value is less than that which was acheived for classical decompositon ; hence ARIMA is preferred over the decomposition model. 
## Hence; showing the finally predicted values below. 

#Lastly, let's plot the predictions along with original values, to get a visual feel of the fit
EU_sales_AA_pred <- c(fitted(EU_sales_autoarima),ts(EU_sales_fcast_AA$pred))
plot(EU_sales_TotalTS, col = "black")
lines(EU_sales_AA_pred, col = "red")

## ************************** Forcasting for EU-Quantity ***************************************************************
#9.1) Time series for Market EU and field quantity

EU_quant_TotalTS <- ts(final_Segment_EU$Monthly.TotalQuantity)
EU_quant_indata <- final_Segment_EU[1:42,]
EU_quant_TS <- ts(EU_quant_indata$Monthly.TotalQuantity)
plot(EU_quant_TS)

#9.2) Smoothing the series using holtwinter method 
cols <- c("red", "blue", "green", "black")
alphas <- c(0.02, 0.1, 0.8)
labels <- c(paste("alpha =", alphas), "Original")
for (i in seq(1,length(alphas))) {
  smoothedseries_Qun_EU <- HoltWinters(EU_quant_TS, alpha=alphas[i],
                                       beta=FALSE, gamma=FALSE)
  
  lines(fitted(smoothedseries_Qun_EU)[,1], col=cols[i], lwd=2)
}
legend("bottomleft", labels, col=cols, lwd=2)

#9.3) Smoothing the series using Moving Average method
w<-1
EU_quant_smseries<- stats::filter(EU_quant_TS, filter=rep(1/(2*w+1),(2*w+1)), 
                                  method='convolution', sides=2)

#Smoothing left end of the time series
diff <- EU_quant_smseries[w+2] - EU_quant_smseries[w+1]
for (i in seq(w,1,-1)) {
  EU_quant_smseries[i] <- EU_quant_smseries[i+1] - diff
}
#Smoothing right end of the time series
n <- length(EU_quant_TS)
diff <- EU_quant_smseries[n-w] - EU_quant_smseries[n-w-1]
for (i in seq(n-w+1, n)) {
  EU_quant_smseries[i] <- EU_quant_smseries[i-1] + diff
}
#9.4) Plot the smoothed time series
EU_quant_timesvals <- EU_quant_indata$No_of_months
lines(EU_quant_smseries, col="blue", lwd=2)

## Summary of all the attritions which were tried before reaching the final whihc is considered here for model building . 
#------------------------|----------------------|-----------------------------| 
# Parameters(EU Quant)   |     Attrition1       |       Attrition 2           |
#------------------------|----------------------|-----------------------------|
#  Window                |    1                 |    4                        |
#  Sin/Cos Coefficient   |    0.5               |    0.7                      |
#  Poly                  |    3                 |    3                        |
#  Model                 | Classical | AutoArima| Classical Deco | AutoArima  |
#  Model Fit             | (2,0,0)   | (2,1,0)  |   (0,0,0)      | (2,1,0)    |
#  Sigma                 | 7284      | 25099    |   17155        |  25099     |
#  LogLikelihood         | -245.89   | -304.31  |   -264.35      | -304.31    |
#  AIC                   | 497.79    | 614.63   |   530.69       |  614.63    |
#  AICc                  | 498.42    | 615.18   |   530.79       |  615.18    |
#  BIC                   | 503       | 620.18   |   532.43       |  620.18    |
#  MAPE                  | 30.39741  | 26.54859 |   32.74805     |  26.54859  |
#-----------------------------------------------------------------------------|

#################### classical decomposition for EU-Quantity ###########################################

# 9.5)First, let's convert the time series to a dataframe
EU_quant_smootheddf <- as.data.frame(cbind(EU_quant_timesvals , as.vector(EU_quant_smseries)))
colnames(EU_quant_smootheddf) <- c('Month', 'Quantity')

#Now, let's fit a multiplicative model with trend and seasonality to the data
EU_quant_lmfit <- lm(Quantity ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3)
                     + Month, data=EU_quant_smootheddf)
summary(EU_quant_lmfit)
accuracy(EU_quant_lmfit)
EU_quant_global_pred <- predict(EU_quant_lmfit, Month=EU_quant_timesvals )
summary(EU_quant_global_pred )
lines(EU_quant_timesvals, EU_quant_global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series We will model it as an ARMA series
EU_quant_local_pred <- EU_quant_TS-EU_quant_global_pred
plot(EU_quant_local_pred , col='red', type = "l")
acf(EU_quant_local_pred)
acf(EU_quant_local_pred, type="partial")
EU_quant_armafit <- auto.arima(EU_quant_local_pred )
tsdiag(EU_quant_armafit)
EU_quant_armafit
### sigma^2 estimated as 8.8e+07:  log likelihood=-443.75
### AIC=889.49   AICc=889.59   BIC=891.23

#We'll check if the residual series is white noise
EU_quant_resi <- EU_quant_local_pred -fitted(EU_quant_armafit)
adf.test(EU_quant_resi,alternative = "stationary")
kpss.test(EU_quant_resi)
#Dickey-Fuller = -6.8673, Lag order = 3, p-value = 0.01
#KPSS Level = 0.042348, Truncation lag parameter = 3, p-value = 0.1

#Now, let's evaluate the model using MAPE First, let's make a prediction for the last 6 months
EU_quant_outdata <- final_Segment_EU[43:48,]
EU_quant_timevals_out <- EU_quant_outdata$No_of_months
EU_quant_global_pred_out <- predict(EU_quant_lmfit,data.frame(Month =EU_quant_timevals_out))
EU_quant_fcast <- EU_quant_global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE
EU_quant_MAPE <- accuracy(EU_quant_fcast ,EU_quant_outdata[,6])[5]
EU_quant_MAPE 
#[1] 30.39741

#Let's also plot the predictions along with original values, toget a visual feel of the fit
class_dec_pred <- c(ts(EU_quant_global_pred),ts(EU_quant_global_pred_out))
plot(EU_quant_TotalTS, col = "black")
lines(class_dec_pred, col = "red")

######################## ARIMA fit for Eu-Quantity ####################################################

EU_quant_autoarima<- auto.arima(EU_quant_TotalTS)
EU_quant_autoarima
tsdiag(EU_quant_autoarima)
plot(EU_quant_autoarima$x, col="black")
lines(fitted(EU_quant_autoarima), col="red")

#Again, let's check if the residual series is white noise
EU_quant_resi_AA <- EU_quant_TotalTS - fitted(EU_quant_autoarima)
adf.test(EU_quant_resi_AA,alternative = "stationary")
kpss.test(EU_quant_resi_AA)
#Dickey-Fuller = -4.4927, Lag order = 3, p-value = 0.01
#KPSS Level = 0.06271, Truncation lag parameter = 3, p-value = 0.1

#Also, let's evaluate the model using MAPE
EU_quant_fcast_AA <- predict(EU_quant_autoarima, n.ahead = 6)
EU_quant_MAPE_AA <- accuracy(EU_quant_fcast_AA$pred,EU_quant_outdata[,6])[5]
EU_quant_MAPE_AA 
# [1] 26.54859
## Since MAPE value is less than that which was acheived for classical decompositon ; hence ARIMA is preferred over the decomposition model. 
## Hence; showing the finally predicted values below. 

#Lastly, let's plot the predictions along with original values, toget a visual feel of the fit

EU_quant_AA_pred <- c(fitted(EU_quant_autoarima),ts(EU_quant_fcast_AA$pred))
plot(EU_quant_TotalTS, col = "black")
lines(EU_quant_AA_pred, col = "red")

###########################################################################################
