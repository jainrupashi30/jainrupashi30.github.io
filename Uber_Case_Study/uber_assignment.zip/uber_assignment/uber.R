## Module : Uber Case Study 
## Name : Rupashi 
## C7 June 2018
## Instruction : Set working directory and place the data file in that path  
## Install required packages like lubridate,ggplot2,dplyr and tidyr 
## setwd... Set the working directory
## setwd("~/rupashi/Data Science/Investment_Case_study")
## setting all the required libraries

install.packages("lubridate")
install.packages("tidyr")
install.packages("dplyr")
install.packages("ggplot2")
##install.packages("stringr")

library(lubridate)
library(tidyr)
library(dplyr)
library(ggplot2)
##library(stringr)

# Reading the Data . 
#read.csv() is used to Read the Uber Request Data file  and storing it in respective data frame i.e. uber_data
 
uber_data <- read.csv("Uber Request Data.csv",stringsAsFactors = F)
# Assumptions : 
## 1.All the Date columns show time in the IST (Indian Standard Time) time zone. 
## 2.Supply refers to the number of Trips Completed and Demand refers to total number of requests received. 
## 3.The data provided is only for 5 days , but similar kind of trends is observed usually for any time period in general. 


# Data Cleaning and preparation 
# 1. Check for NA values in the dataframe . complete.cases() function helps to identify the NA values presemt in the data frame.
uber_NA_data <- uber_data[!complete.cases(uber_data),]

# After analysing the data in the newly created data frame uber_NA_data,observed that the column Drop Timestamp had NA values for Trip Status as Cancelled or No Cars Available. Also, the column Driver id has NA values for those trips whose staus is No Cars Available. 
# These NA values are quite logical as per the situation; hence not removing these as it would result in a loss for potential data analysis for the problem identification. 
# This data frame uber_NA_data is nowhere used in the further analysis as it was just created to identify NA values . 

# 2. Also checked for the cases of the data present in each columns. The cases are consistent throughout so no need to change it in lower or upper case. 

# 3 . Format for the date columns Request timestamp and Drop timestamp are not consistent. At places dates are separated by '/' but at places by'-'. 
# Hence created a uniform format for all the date values. 
# parse_date_time() function returns a standard common format for all the date values present in the columns.  

uber_data$Request.timestamp <- parse_date_time(uber_data$Request.timestamp,orders=c("%d%m%Y H:M:S","%d%m%y H:M"))
uber_data$Drop.timestamp <- parse_date_time(uber_data$Drop.timestamp,orders=c("d m Y H:M:S","d m Y H:M"))

# 4. Checked for duplicate values and removed any duplicate values form the data frame uber_data. duplicated() function returns the set of duplicate values present in the specified data frame or vector. 
uber_data <- uber_data[!duplicated(uber_data),]
# As there were no duplicate values in the data frame; hence the records after removing the duplicates is same as before. 

#5 Deriving New Data variables , which will be useful for further analysis

#  i)   Derived the variable 'Route' to Define the from and to points like Airport to City or City to Airport. 
# ifelse() function returns a value if the condition mentioned evaluates to True , otherwise returns the second value specified. 

uber_data$Route <- ifelse(uber_data$Pickup.point == "Airport","Airport to City","City to Airport")

# ii) Derived the Variables Request time,Drop time, Request hour, Request Date as they can be used for further day wise, hour wise analysis. 
# The column Request time and Drop time can be used to bin the time into categories like Early Morning,Morning,Evening etc. for analysis . 
#  Variable Request.time derived . format() function is used to derive the mentioned like time,hour,day etc. from the Date time type of column. 

uber_data$Request.time <- format(uber_data$Request.timestamp,"%H:%M:%S")

# Variable Drop.time derived using the function format()

uber_data$Drop.time <- format(uber_data$Drop.timestamp,"%H:%M:%S")

# Variable Request.hour derived using the function format()

uber_data$Request.hour <- format(as.POSIXct(uber_data$Request.time,format="%H:%M:%S"),"%H")

# Variable Request.date derived using the function format()

uber_data$Request.date <- format(as.POSIXct(uber_data$Request.timestamp,format="%Y%m%d H:M:S"),"%d")

#iii) Derived Time Slots

# Derived the variable  Request Time slot to split the time into categories for further analysis and hypothesis. 
## Created 5 time slots as Early Morning,Morning,Afternoon etc. as per the probable distribution of the requests which can be received during various times of the day. 
## Time Bins were created so that slot wise gap demand analysis can be done and specific time slots which need attention can be identified and addressed. 
## Creating Time Slots will help us do a Segmented analysis on the data and hence we would be able to identify whih segments need to be looked into more closely.
# Built a custom function to derive the Bins. Following time bins are created 
# i)   03:00:00 - 04:59:59 -- Early Morning 
# ii)  05:00:00 - 11:59:59 -- Morning
# iii) 12:00:00 - 16:59:59  -- Afternoon 
# iv)  17:00:00  - 23:59:59  -- Evening & Late evening 
# v)   00:00:00  - 02:59:59  -- Mid Night


# Built a custom function to derive a new column Timeslot for each row of the Request time present in the data frame . 
# Passed a time variable to the function to get the timeslot in return. 
functimeslot <- function(Ptimestamp)
{
  if (!is.na(Ptimestamp) && Ptimestamp >= "03:00:00" && Ptimestamp <= "04:59:59")
    return("Early Morning")
  else if (!is.na(Ptimestamp) && Ptimestamp >= "05:00:00" && Ptimestamp <= "11:59:59")
    return("Morning")
  else if (!is.na(Ptimestamp) && Ptimestamp >= "12:00:00" && Ptimestamp <= "16:59:59")
    return("Afternoon")
  else if (!is.na(Ptimestamp) && Ptimestamp >= "17:00:00" && Ptimestamp <= "23:59:59")
    return("Evening and Late Evening")
  else if (!is.na(Ptimestamp) && Ptimestamp >= "00:00:00" && Ptimestamp <= "02:59:59")
    return("Mid Night")
 }

# Derived a new column Request timeslot . sapply() function is used to apply the custom function created above over a range of values of the specified column i.e. Request.time here. 
uber_data$Request.timeslot <- sapply(uber_data$Request.time,functimeslot)
# as.character() is used to convert the column timeslot to character type. 
uber_data$Request.timeslot <- as.character(uber_data$Request.timeslot)
# write.csv() function is used to write the cleaned and derived data to the desired excel file which can be used for plotting in Tableau 
#write.csv(uber_data,"uber_data_final.csv"). Used this only to get the desired data in excel. Later on commented here. 

########################################################################################################

#Plots : 
#1

# We are plotting hour wise Status of the Requests to identify daily trends of the cancellation or No Cars available for each day. This will help us identify the time slots which contibute majorly to the supply demand gap.
#ggplot() is used to plot the specific values of a data frame.We have Request.hour as the aesthetic for X axis and different Status shown by different colours using the option fill. 
#geom_bar() is used to specify what kind of graph is needed. Since we are analysing the number of requests here ; hence bar graph would be the most suitable graph here. 
# facet_wrap() is used to plot more than one graphs in the same frame by a new different variable i.e. Request Date.
# labs() iis used to give names to the x axis,y axis and any other variables shown via fill in the graph. 

p1<- ggplot(uber_data,aes(x=as.factor(Request.hour), fill=Status))+geom_bar(position="dodge")
p1+facet_wrap( ~ Request.date,nrow =5,ncol=1)+labs(x="Hour",y="No. of Requests",fill="Status")

# P1 shows similar hour wise trends for the status of the requests for each day. 

#2 We are plotting hour wise Route of the requests to identify the hour wise distribution of the routes for each day
# used ggplot(),facet_wrap(),lab() functions
p2<- ggplot(uber_data,aes(x=as.factor(Request.hour), fill=Route))+geom_bar(position="dodge")
p2+facet_wrap( ~ Request.date,nrow =5,ncol=1)+labs(x="Hour",y="No. of Requests",fill="Route")

# P2 shows similar hourly trends for the routes on each day. 

#3 Next We will plot Slot wise number of requests for all the days; along with the distribution of the Status i.e. Trips Completed, No Cars available or Cancelled. 
# This is will help us identify the slots where the supply demand gap is maximum. 
# factor() function is used to convert a string to factor. Here Since we have particular timeslots as the values in the derived column Request timeslot hence convert it into factor and defining the levels , so that it is visible clearly in graph as well. 
uber_data$Request.timeslot <- factor(uber_data$Request.timeslot,levels=c("Early Morning","Morning","Afternoon","Evening and Late Evening","Mid Night"))

# used ggplot(),facet_wrap(),lab() functions
# used geaom_text() to show the value in each stack/dodge of the bar chart to make it more descriptive. 
p3 <- ggplot(uber_data,aes(x=uber_data$Request.timeslot,fill=uber_data$Status))+geom_bar(position="stack")
p3+geom_text(aes(label =..count..,y=..count..),stat="count",size=3,position=position_stack(vjust=0.5))+labs(x="Timeslot",y="Count",fill="Status")+theme_classic()

# From P3 we can infer that the Supply-Demand gap is maximum during 'Morning' and 'Evening and Late Evening' time slots. 
## For Morning the gap is 2517-1085 = 1432  i.e. 57%
## For Evening and Late Evening the gap is 2840-1041 = 1799 i.e. 63%
## Hence, we would further analyse the Morning and Evening slots to get a better picture as to which route contributes to the gap more. 

#4
# Next we will plot Route wise Status of the trips for Morning i.e. one of the time slots identified above. This will help us analyse which route contributes to the gap more. 
## filter() function is used to filter specific values i.e. "Morning" here for the Request.timeslot column if uber_data df. 
uber_morning <- filter(uber_data,uber_data$Request.timeslot == "Morning")

# used ggplot(),facet_wrap(),lab() functions
# used geaom_text() to show the value in each stack/dodge of the bar chart to make it more descriptive. 
## theme_grey() is used to specify a theme which makes to graph presentable and easy to read. 
p4 <- ggplot(uber_morning,aes(x=uber_morning$Route,fill=uber_morning$Status))+geom_bar(position="stack")
p4+geom_text(aes(label =..count..,y=..count..),stat="count",position=position_stack(vjust=0.5))+labs(x="Route",y="Count",fill="Status")+theme_grey()

# From P4 we can infer that the gap is more for the City to Airport Route. 
## Supply from City is 601 and demand is 601+468+883 = 1952 ; hence  the gap is 1351 i.e. 69%.
### Driver cancellation is maximum in morning on City to Airport route.


#5 
# Next we will plot Route wise Status of the trips for Evening and Late Evening i.e. second time slot identified above. This will help us analyse which route contributes to the gap more. 
## filter() function is used to filter specific values i.e. "Evening and Late Evening" here for the Request.timeslot column of uber_data df. 

uber_evening <- filter(uber_data,uber_data$Request.timeslot == "Evening and Late Evening")

# used ggplot(),facet_wrap(),lab() functions
# used geaom_text() to show the value in each stack/dodge of the bar chart to make it more descriptive. 
p5 <- ggplot(uber_evening,aes(x=uber_evening$Route,fill=uber_evening$Status))+geom_bar(position="stack")
p5+geom_text(aes(label =..count..,y=..count..),stat="count",position=position_stack(vjust=0.5))+labs(x="Route",y="Count",fill="Status")+theme_grey()


#  From P5 we can infer that the gap is more for the Airport to City Route. 
## Supply from Airport is 515 and demand is 515+1457+109 = 2081,hence gap is 1566 i.e. 75%
## Unavailability of cars is higher in the evening on Airport to City route.



