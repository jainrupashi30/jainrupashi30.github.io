## Module : Investment Case Study 
## Names : Preksha,Rupashi,Rajshree and Rushikesh
## Instruction : Set working directory, path and 3 data files companies, rounds2 and mapping in the same path. 
## Install packages dplyr and tidyr 
## setwd... Set the working directory
## setwd("~/rupashi/Data Science/Investment_Case_study")
## setting all the required libraries
install.packages("tidyr")
install.packages("dplyr")
install.packages("gdata")

library(dplyr)
library(tidyr)
library(gdata)

# read.delim() and read.csv() functions is used to Read the companies and rounds 2 data file  and storing it in respective data frames i.e companies and rounds2 

companies <- read.delim("companies.txt",header=TRUE,sep="\t",stringsAsFactors = FALSE )
rounds2 <- read.csv("rounds2.csv",stringsAsFactors = FALSE )

# tolower() function is used to Convert the common column to lower case so that both the dfs can be merged successfully 

companies$permalink <- tolower(companies$permalink)
rounds2$company_permalink <- tolower(rounds2$company_permalink)

# Checkpoint 1 Understanding the Data Set 
# group_by() function used to Group by on the distinct column company_permalink and permalink to get the unique number of companies
round_group_by <- group_by(rounds2,company_permalink)

#1.1 count() function used to Get the unique companies in rounds data frame 
unique_company_rounds <- count(rounds2,company_permalink)

#1.2 count() function used to Get the unique companies in companies data frame 
unique_company_companies <- count(companies,permalink,na.rm=T)

#1.5 merge() function used to Merge the two data frames to get one master frame 
master_frame <-merge(x=rounds2,y=companies,by.x="company_permalink",by.y="permalink")
 

# CheckPoint 2 
# Grouping by the data frame by the column funding round type to perform average on raised amount USD  funding type wise .  
# summarise() function used to perform aggregate functions like mean and count 
# filter() function used to slice data for one particular value of funding_round_type
 g_funding_type <- group_by(master_frame,funding_round_type)
 avg_funding <- summarise(g_funding_type,value=mean(raised_amount_usd,na.rm=TRUE))

#2.1 Calculated average of "Venture:: funding type  
avg_venture <- filter(avg_funding,funding_round_type=="venture")

#2.2 Calculated average of "Angel": funding type
avg_angel <- filter(avg_funding,funding_round_type=="angel")

#2.3 Calculated average of "Seed": funding type
avg_seed <- filter(avg_funding,funding_round_type=="seed")

#2.4 Calculated average of "private equity": funding type
avg_private_equity <- filter(avg_funding,funding_round_type == "private_equity")


#Checkpoint3 to get the top 9 sountires as per the total funding received for "venture" type and top3 English speaking countries

# First filtered on "Venture" type funding round type and then calculated the total funding for the countries to fetch top9
filter_venture_mf <- filter(master_frame,funding_round_type =="venture")
# Removed NA and null values from data frame.
#use complete.cases() to remove all NA values
filter_venture_mf1 <- filter_venture_mf[complete.cases(filter_venture_mf),] 
filter_without_final <- filter_venture_mf1[!(filter_venture_mf1$country_code == ""), ]
# Performed a group by on country code to get the total funding country wise 
country_group_by <- group_by(filter_without_final,country_code)
# Calculated country wise total funding received. 
total_funding <- summarise(country_group_by, total= sum(raised_amount_usd,na.rm=TRUE))
# Fetched the top 9 countries based on total funding received . And then out of them only considered top 3 English speaking countries in the result in Excel. 
top_9 <- head(arrange(total_funding,desc(total)),9)

# Chekpoint 4 Read the mapping.csv file and merge it into the master frame to get the primary and main sector mappings

# gather() function is used to convert columns into rows with value 0 or 1 for each row 
mapping <- read.csv("mapping.csv",header=TRUE,stringsAsFactors = FALSE)
str(mapping)
mapping <- gather(mapping,main_sector,value,Automotive...Sports:Social..Finance..Analytics..Advertising)

#removing 0 values and blank columns
mapping_wihtout_0val <- mapping[!(mapping$value==0) & !(mapping$category_list== ""),] 

#removing value column as it has same value 1 for each row and is of no significance
mapping_final <- mapping_wihtout_0val[,-3]


#?separate
# separate() function is used to separate the string on the basis of a repeating pattern which is '|' here . 
# This function was used to identify the primary sector from the category_list 
# parameter'drop' was used in the command to drop all the rows except the first one i.e. the Primary sector here. 
# Fetched the primary sector of each row in master_frame
mapping_separated <- separate(master_frame,category_list , into=c("primary_sector"), sep="\\|",extra='drop')

# Removed blank values in the column primary sector in the master data frame
mapping_separated <- mapping_separated[!(mapping_separated$primary_sector== ""),]

# Converted the common columns on which the data merging will take place to lower case so that it exaclty matches and data frame is merged properly without any loss of data
mapping_separated$primary_sector <- tolower(mapping_separated$primary_sector)
mapping_final$category_list <- tolower(mapping_final$category_list)

# Merging the master data frame to mapping data frame to get all the dimensions in one frame. 
final_master_frame <- merge(x=mapping_separated,y=mapping_final,by.x="primary_sector",by.y="category_list",all.x=TRUE)

#Checkpoint 5 

# Created three new data frames of the top 3 countries and 'Venture' funding type and then calculated the number of investments 
# and total amount invested sector wise for each of the top 3 countries. 

D1_country <- filter(final_master_frame,country_code =='USA',funding_round_type =="venture")
D2_country <- filter(final_master_frame,country_code =='GBR',funding_round_type =="venture")
D3_country <- filter(final_master_frame,country_code =='IND',funding_round_type =="venture")

# Performed grouping on main_sector to perform aggregate function on main sector 
group_by_d1 <- group_by(D1_country,main_sector)
group_by_d2 <- group_by(D2_country,main_sector)
group_by_d3 <- group_by(D3_country,main_sector)

# Calculated the  sector wise  number of investments for each country
count_d1 <- count(D1_country,main_sector)
count_d2 <- count(D2_country,main_sector)
count_d3 <- count(D3_country,main_sector)

# Calculted the sector wise total amount invested in each country 
total_amount_d1 <- summarise(group_by_d1,total_amount=sum(raised_amount_usd,na.rm= TRUE))
total_amount_d2 <- summarise(group_by_d2,total_amount=sum(raised_amount_usd,na.rm= TRUE))
total_amount_d3 <- summarise(group_by_d3,total_amount=sum(raised_amount_usd,na.rm= TRUE))

# Then,for each country, displayed all the info i.e. count  of investments along with all the other dimensions 
# present in the master frame , in one final data frame . 
merge_d1_count <- merge (x=D1_country,y=count_d1,by.x="main_sector",by.y="main_sector",all.x=TRUE)
merge_d2_count <- merge (x=D2_country,y=count_d2,by.x="main_sector",by.y="main_sector",all.x=TRUE)
merge_d3_count <- merge (x=D3_country,y=count_d3,by.x="main_sector",by.y="main_sector",all.x=TRUE)

# colnames() function is used to Change the name of the column 17 so that it can be easily comprehended. 
colnames(merge_d1_count)[17] <- "count_investment"
colnames(merge_d2_count)[17] <- "count_investment"
colnames(merge_d3_count)[17] <- "count_investment"

# For each country, displayed all the info sum of investments along with all the other dimensions 
# present in the master frame , in one final data frame . 
D1 <- merge(x=merge_d1_count,y=total_amount_d1,by.x="main_sector",by.y="main_sector",all.x=TRUE)
D2 <- merge(x=merge_d2_count,y=total_amount_d2,by.x="main_sector",by.y="main_sector",all.x=TRUE)
D3 <- merge(x=merge_d3_count,y=total_amount_d3,by.x="main_sector",by.y="main_sector",all.x=TRUE)


# write.csv() function is used to Write the data frame into excel to see the info
#write.csv(D1,"D1.xls")   
#write.csv(D2,"D2.xls")
#write.csv(D3,"D2.xls")

# Checkpoint 6.1 Calculated the sum of all funding types and each funding type to get the fraction value for plotting in Tableau 

sum_funding <- summarise(g_funding_type,value=sum(raised_amount_usd,na.rm=TRUE))
sum_venture <- sum_funding[which(sum_funding$funding_round_type=="venture"),]
sum_angel <- filter(sum_funding,funding_round_type=="angel")
sum_seed <- filter(sum_funding,funding_round_type=="seed")
sum_private_equity <- filter(sum_funding,funding_round_type == "private_equity")
