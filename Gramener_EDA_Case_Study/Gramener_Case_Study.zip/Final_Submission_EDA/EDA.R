## Module - Group Project - EDA Case Study
## Name - Preksha,Rupashi,Rajshree
## Instructions - Set the working directory path and
## Unzip datafile (loan.csv) and place in the same path.

# Remove existing memory space if any
remove(list=ls())

## read.csv() function is used to read given csv file into a data frame that it creates called uber.
## Argu-stringAsFactor is set as False so strings in a data frame is treated as just string not as a factor. 
loan <- read.csv("loan.csv",stringsAsFactors = F)

## Libraries
# lubridate is for function parse_date_time()
# ggplot2 is for function ggplot()
# corrplot is for function cor()
# gmodels is for CrossTable()

install.packages("lubridate")
install.packages("ggplot2")
install.packages("tidyr")
install.packages("dplyr")
install.packages("corrplot")
install.packages("gmodels")

library(gmodels) 
library(tidyr)
library(dplyr)
library(lubridate)
library(ggplot2)
library(corrplot)

##1) Data Cleaning
# 1.1) Remove NA values from dataset using colSums() function  
loan_data <- loan[colSums(!is.na(loan))!=0]
# 1.2) Remove columns having more than 30 % null values 

loan_data <- loan_data[,colMeans(is.na(loan_data)) <=0.30]
loan_data <- loan_data[,colSums(is.na(loan_data)) <=0.30]
# 1.3) Remove columns having zero variance using filter() and unique() functions

loan_data <- Filter(function(x)(length(unique(x))>1),loan_data)

# 1.4) Checked for duplicate rows and removed if any usinf duplicated() function

loan_data <- loan_data[!duplicated(loan_data),]

# 1.5) check the spread of annual_income and remove outliers using summary() function 

summary(loan_data$annual_inc)
loan_data <- loan_data[-which(loan_data$annual_inc %in% c(3900000,6000000)),]

##2) Data manipulation 
# 2.1) Removed % and Convert int rate and revol utils to numeric column

loan_data$int_rate = as.numeric(gsub('%','',loan_data$int_rate))
loan_data$revol_util = as.numeric(gsub('%','',loan_data$revol_util))

# 2.2) Check for missing value imputation, replaced column values as "Not Available" 

loan_data$emp_length = gsub('n/a','Not Available',loan_data$emp_length)
loan_data$emp_title <- ifelse(loan_data$emp_title %in% c(""," "),"Not Available",loan_data$emp_title)

##3) Derived metrics
#3.1) Extract years from issue date using parse_date_time) and format() functions

loan_data$issue_d <- parse_date_time(loan_data$issue_d,'%b%y')
loan_data$issue_year <- format(loan_data$issue_d,"%Y")
#3.2) Derive monthly income from annual income using sapply() function

loan_data$monthly_income <- sapply(loan_data$annual_inc,function(x)(x/12))

#3.3) Derive loan to income ratio using mutate() function 

loan_data <- mutate(loan_data,monthly_dti=installment/monthly_income)

#3.4) Derive new variables bins for annual income,loan amount and interest rate
##3.4.1) Binning of loan amount

summary(loan_data$loan_amnt)
func_loan_amt <- function(P_loan_amt)
{
  if (P_loan_amt>=0 && P_loan_amt<=5000)
    return("0-5000")
  else if (P_loan_amt >5000 && P_loan_amt<=10000)
    return("5000-10000")
  else if (P_loan_amt >10000 && P_loan_amt<=15000)
    return("10000-15000")
  else if (P_loan_amt >15000 && P_loan_amt<=20000)
    return("15000-20000")
  else if (P_loan_amt >20000 && P_loan_amt<=25000)
    return("20000-25000")
  else if (P_loan_amt >25000 && P_loan_amt<=30000)
    return("25000-30000")
  else if (P_loan_amt >30000 && P_loan_amt<=35000)
    return("30000-35000")
}
loan_data$loan_amnt_bin <- sapply(loan_data$loan_amnt,func_loan_amt)

##3.4.2) Binning of annual inc amount
func_annual_inc <- function(P_annual_inc)
{
  if (P_annual_inc>=0 && P_annual_inc<=25000)
    return("0-25000")
  else if (P_annual_inc >25000 && P_annual_inc<=50000)
    return("25000-50000")
  else if (P_annual_inc >50000 && P_annual_inc<=75000)
    return("50000-75000")
  else if (P_annual_inc >75000 && P_annual_inc<=100000)
    return("75000-100000")
  else if (P_annual_inc >100000 && P_annual_inc<=125000)
    return("100000-125000")
  else if (P_annual_inc >125000 && P_annual_inc<=150000)
    return("125000-150000")
  else if (P_annual_inc >150000 && P_annual_inc<=175000)
    return("150000-175000")
  else if (P_annual_inc >175000)
    return("175000 and above")
}
loan_data$annual_inc_bin <- sapply(loan_data$annual_inc,func_annual_inc)

##3.4.3) Binning of interest rate
func_interest_rate <- function(P_interest_rate)
{
  if (P_interest_rate>2 && P_interest_rate<=4)
    return("2-4")
  else if (P_interest_rate>4 && P_interest_rate<=6)
    return("4-6")
  else if (P_interest_rate >6 && P_interest_rate<=8)
    return("6-8")
  else if (P_interest_rate >8 && P_interest_rate<=10)
    return("8-10")
  else if (P_interest_rate >10 && P_interest_rate<=12)
    return("10-12")
  else if (P_interest_rate >12 && P_interest_rate<=14)
    return("12-14")
  else if (P_interest_rate >14 && P_interest_rate<=16)
    return("14-16")
  else if (P_interest_rate >16 && P_interest_rate<=18)
    return("16-18")
  else if (P_interest_rate >18 && P_interest_rate<=20)
    return("18-20")
  else if (P_interest_rate >20 && P_interest_rate<=22)
    return("20-22")
  else if (P_interest_rate >22 && P_interest_rate<=24)
    return("20-24")
  else if (P_interest_rate >24)
    return("24 and above")
}
loan_data$int_rate_bin <- sapply(loan_data$int_rate,func_interest_rate)

# Seprate Numerical and Categorical variables in different dfs for further analysis
chr_var <- names(loan_data)[which(sapply(loan_data,is.character))]
num_var <- names(loan_data)[which(sapply(loan_data,is.numeric))]

# Prepare New datasets 
loan_numeric <- loan_data[,num_var]
loan_char <- loan_data[,chr_var]
## Data Understanding
names(loan_data)
dim(loan_data)
names(loan_numeric)
dim(loan_numeric)
names(loan_char)
dim(loan_char)
# Write the data in files for graph plot 
#write.csv(loan_data,"loan_data.csv")
#write.csv(loan_char,"loan_char.csv")
#write.csv(loan_numeric,"loan_numeric.csv")
#*******************************************************************************************
#1) Data Distribution 

#1.1)Yearly distributions of loan applications 

ggplot(loan_data, aes(x=issue_year)) + geom_bar() + labs(x="Loan Issue Year",y="Number of Applications",title="Yearly Trends") +
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+theme_gray() 
# We observed Highest number of applications were received in 2011 i.e. approx. 54%. 

#1.2) Status wise distributions of loan applications 

ggplot(loan_data, aes(x=loan_status,fill=loan_status)) + geom_bar() + labs(x="Loan Status",y="Number of Applications",title="Loan status Trends") +
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+theme_gray()
# We observed 14% of the applicants in the data set  were charged off. 

#1.3) Loan Amount Distribution

boxplot(loan_data$loan_amnt)
# We observed mostly the loan amount lies between 5,500 to 15000 USD 

#1.4) Annual Income Distribution

boxplot(loan_data$annual_inc)
# we observed Mostly the annual income lies between 40,000 to 80,000 USD 

#1.5) Interest rate Distribution

boxplot(loan_data$int_rate) #~loan_data$loan_status)
# we observed Mostly the interest rate lies between 9.25% and 14.59%. 

## Univariate Analysis
#1) Purpose of loan

ggplot(loan_data, aes(x=purpose,fill=loan_status)) + geom_bar() + labs(x="Loan Purpose",y="Number of Applications",title="Loan Purpose TrendS") +
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=1.05))+theme(axis.text.x = element_text(angle = 60, hjust = 1))
# We observed 3 top most purposes for which maximum number of loan applications were received i.e. Debt Consolidation, Credit Card and Others

#2) Grade

ggplot(loan_data, aes(x=grade,fill=loan_status)) + geom_bar() + labs(x="Grade",y="Number of Applications",title="Grade Trends") +
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+theme_gray()
#We observed that more percent of loans charged off for grades C,D and E 

#3) Interest Rate

ggplot(loan_data, aes(x=int_rate_bin,fill=loan_status)) + geom_bar() + labs(x="Interest Rates Bin",y="Number of Applications",title="Interest Rate Trends") +
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+theme_gray() + coord_flip()
#We observed that interest rate falling within range of 10 % till 18% have higher percentages of charged off  loans

#4) Loan amount

ggplot(loan_data, aes(x=loan_amnt_bin,fill=loan_status)) + geom_bar() + labs(x="Loan Amount Bins",y="Number of Applications",title="Loan Amount Trends") + theme_gray() + 
geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+theme_gray() + coord_flip()
#We observed that the applicants who applied for loan amounts within range 0-15000 USD are likely to default as they have higher percentages for charged off loans. 

#5) Employement Length

ggplot(loan_data,aes(x=emp_length,fill=loan_status))+geom_bar()+labs(x="Emp Length",y="Number of Applications",title="Employement Length Trends")+
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.5))+theme_gray() + coord_flip()
#We observed that applicants whose employment length falls in range of 10+ years and <1 year have higher percentages of charged off loans. 

#6) State

ggplot(loan_data, aes(x=addr_state,fill=loan_status)) + geom_bar() + labs(x="state",y="NUmber of Applications",title="State Trends") +
theme(axis.text.x = element_text(angle = 60, hjust = 1))
# We observed The highest charged off loans were also from Canada, New York and Texas

#7) Term

ggplot(loan_data, aes(x=term,fill=loan_status)) + geom_bar() + labs(x="Term",y="Number of Applications",title="Loan Terms Distribution")+ 
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+theme_gray() 
# We observed that the percentage for the charge off loans is more where the term is 60 months

#8) Home ownership

ggplot(loan_data, aes(x=home_ownership,fill=loan_status)) + geom_bar() + labs(x="Home ownership",y="Number of Applications",title="Home Ownerwise Trends") +
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.7))+theme_gray() 
#We observed that the percentage for the charge off loans is more for Mortgage and Rent type

#*******************************************************************************************
## BiVariate Analysis

#1) Grades distribution over Interest Rate
ggplot(loan_data,aes(x=grade,y=int_rate,fill=loan_status))+geom_boxplot()+labs(x="Grade",y="Interest Rate",title="Interest Rate vs. Grade")+theme_grey()
# We observed As the interest rate is increasing the probability that person will default is increasing with highest of 13 to 21 %.

#2) Interest Rate Distribution along with loan status 
boxplot(loan_data$int_rate~loan_data$loan_status)
# We observed Interest rate lies between 11% to 16% for "Charged Off" cases and 


#3) Grades distribution over Home Ownership

ggplot(subset(loan_data,loan_data$home_ownership %in% c("MORTGAGE","RENT")), aes(grade,fill= loan_status)) +
  geom_bar() + facet_wrap(~home_ownership) + 
  labs(x = "Grade", y = "Number of Applications", title = "Grade distribution over Home Ownership") + 
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.7))+theme_gray() 
# We observed People in 'MORTGAGE' and 'RENT' have much more demands of borrowing money than people in 'OWN'. 
## Also more percent of applicants default for grades C,D,E , hence there is more probability for these to default. 


#4) Grade distribution over purpose
ggplot(subset(loan_data,loan_data$purpose %in% c("credit_card","debt_consolidation","other")),aes(grade,fill= loan_status)) +
  geom_bar()+ facet_wrap(~purpose) +
  labs(x="Grade", y="Number of Applications",title="Grade distribution over purpose")+
    geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.7))+theme_gray() 
# We observed loan deafault probablity is more for grade C,D and E applicants for purpose Credit card,Debt cosolidation and others 


#5) Loan Amount distribution over Employment Length
ggplot(subset(loan_data,loan_data$emp_length %in% c("< 1 year","10+ years")),aes(loan_amnt_bin,fill= loan_status)) +
geom_bar()+ facet_wrap(~emp_length) +
  labs(x="Loan Amount Bins", y="Number of Applications",title="Grade distribution over Employment Length")+
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.7))+
  theme(axis.text.x = element_text(angle = 60, hjust = 1))
# We observed that applicants with employment length <1 year and 10+ years are likely to default for loan amount upto $15000.

#6) Loan Amount distribution over State
ggplot(subset(loan_data,loan_data$addr_state %in% c("CA","NY","TX")),aes(loan_amnt_bin,fill= loan_status)) +
  geom_bar()+ facet_wrap(~addr_state) +
  labs(x="Loan Amount Bins", y="Number of Applications",title="Grade distribution over State")+
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.7))+
  theme(axis.text.x = element_text(angle = 60, hjust = 1))
#We observed that applicants belonging to Canada, New York and Texas who have applied for loan amount up to 15000 USD are likely to default

#7) Grades distribution over Loan amount & status	

ggplot(loan_data,aes(x=grade,y=loan_amnt,fill=loan_status))+geom_boxplot()+labs(x="Grade",y="Loan Amount",title="Grade distribution over Loan amount and status")+theme_grey()
#We observed We observe loan amount range is relatively higher for grades E,F and G as compared to other grades for those whi charged off 

#8) Grades distribution over Loan term & year	 
ggplot(loan_data, aes(x = issue_year)) +
  geom_bar(aes(fill = grade)) + facet_grid(~term) + 
  labs(title = "Grade distribution over term and year", x = "Issued Year", y = "NUmber of Applications") + theme_bw() +
  theme(axis.text.x = element_text(angle = 60, hjust = 1))
# we observed the loans with 60 month term belonging to grades C,D and E have a higher probability to default in year 2010 & 11. 
## Also all current applications have loan term of 60 months. 

#9) Monthly DTI to grade
ggplot(loan_data, aes(monthly_dti))  + geom_density(aes(fill = grade)) +
  facet_grid(grade ~ .)+labs(title = "Grade wise Loan to Income Ratio Trends ", x = "Loan to Income Ratio (Monthly)", y = "Density") + theme_bw()

## This graph shows that as the grade of the loan increases from A to G the dti values increase.

#10) Correleation between numeric variables in the dataset. Used the datafrme loan_numeric which is a subset of all the numeric variables in the loan_data dataframe. 
M <- cor(select(loan_numeric,loan_amnt,funded_amnt,annual_inc,int_rate,dti,monthly_dti,revol_bal))
corrplot(M,method="square")
# We observed loan_amnt' and 'funded_amnt' are closely interrelated.So we can take any one column out of them for our analysis.

#CrossTables These help us visualise the bivariate analysis. Inbuilt function CrossTable() is used for the same.

CrossTable(loan_data$emp_length,loan_data$loan_status,prop.r = TRUE,
           prop.c = FALSE,prop.t = FALSE,prop.chisq = FALSE,format = "SPSS")

CrossTable(loan_data$verification_status,loan_data$loan_status,prop.r = TRUE,
           prop.c = FALSE,prop.t = FALSE,prop.chisq = FALSE,format = "SPSS")

CrossTable(loan_data$grade,loan_data$loan_status,prop.r = TRUE,
           prop.c = FALSE,prop.t = FALSE,prop.chisq = FALSE,format = "SPSS")

CrossTable(loan_data$home_ownership,loan_data$loan_status,prop.r = TRUE,
           prop.c = FALSE,prop.t = FALSE,prop.chisq = FALSE,format = "SPSS")

CrossTable(loan_data$purpose,loan_data$loan_status,prop.r = TRUE,
           prop.c = FALSE,prop.t = FALSE,prop.chisq = FALSE,format = "SPSS")




