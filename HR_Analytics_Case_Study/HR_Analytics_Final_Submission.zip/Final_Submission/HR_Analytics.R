## Case Study - HR Analytics Case Study
## Name - Preksha,Rupashi and Rajshree
### Business Understanding:

# The company employees around 4000 employees at any given point of time.
#But, every year around 15 % of the employees leave the company and have to be replaced with the talent pool available in the market.
## Due to attrition the company faces many issues like missing timelines,maintaining separate department for recruiting new talent etc. 
## We have been provided with all the employee related information in different excel files. 


## AIM:

# The aim is to  predict the probability of attrition of any given employee.  
# Understand the factors on whcih the employee attrition would depend and hence identify the changes 
## should be made to the workplace in order to get most of the employees to stay. 

####################################################################################################
## Instructions - Set the working directory path and place the datafiles in the same path.
## setwd("~/Predictive analysis/Case_Study_HR/PA-I_Case_Study_HR_Analytics")
# Install and Load the required packages
install.packages("MASS")
install.packages("car")
install.packages("e1071",dependencies = TRUE)
install.packages("caret", dependencies = c("Depends", "Suggests"))
install.packages("cowplot")
install.packages("caTools")
install.packages("GGally")
install.packages("ggplot2")
install.packages("tidyr")
install.packages("dplyr")
install.packages("prettyunits")

library(MASS)
library(car)
library(e1071)
library(caret)
library(ggplot2)
library(cowplot)
library(caTools)
library(dplyr)
library(tidyr)
library(lubridate)
library(GGally)
library(ROCR)

# Remove existing memory space if any & suppress warning
remove(list=ls())
suppressWarnings(library(RODBC))

############################################################################################################
## 1) Data Understanding 
# read.csv() function is used to read given csv file into a data frame 
# Argument - check.names is set as false is used to convert valid column name
# Argument-stringAsFactor is set as False so strings in a data frame is treated as just string not as a factor. 

general_data <- read.csv("general_data.csv", stringsAsFactors = F)
employee_survey_data <- read.csv("employee_survey_data.csv", stringsAsFactors = F)
manager_survey_data <- read.csv("manager_survey_data.csv", stringsAsFactors = F)
in_time <- read.csv("in_time.csv", stringsAsFactors = F,check.names = FALSE)
out_time <- read.csv("out_time.csv", stringsAsFactors = F,check.names = FALSE)

# Before performing merge operation ,check for duplicate values using unique() and lenght(),
# And this shows data files have same number of unique observations (#4410)
# setdiff() function is used to check the identical employeeID across data frames . Since value of setdiff is 0 that means
# all the employee IDS are identical in all the files. 

length(unique(general_data$EmployeeID))   
length(unique(employee_survey_data$EmployeeID))
length(unique(manager_survey_data$EmployeeID)) 
setdiff(general_data$EmployeeID,employee_survey_data$EmployeeID)
setdiff(general_data$EmployeeID,manager_survey_data$EmployeeID) 


# Merge() function is used to merge two different dataframes using common column (employeeid)
# here we have merged employee and manager datafile into general data file 
# "empdata" is the newly created merged dataframe with #4410 observations and 29 variables
# Removed near zero variances columns (i.e.EmployeeCount,Over18 and standardHrs)   
empdata <- merge(general_data,employee_survey_data, by="EmployeeID", all = T)
empdata <- merge(empdata,manager_survey_data, by="EmployeeID", all = T)
empdata <- empdata[,c(-9,-16,-18)] #4410 observation of 26 variables

############################################################################################################
## 2) Data cleanup and Data manipulation 

# colSums() function is used to remove NA columns from In/Out time datafiles
# colnames() function is used to give column heading to first column of in/out time file
# Finally in_time/out_time data frames have #4410 observations of 250 variables
in_time <- in_time[colSums(!is.na(in_time))!=0]
out_time <- out_time[colSums(!is.na(out_time))!=0]
## Assigning column name EmployeeID to the first column of in and out time dataframes. 
colnames(in_time)[1] <- "EmployeeID"
colnames(out_time)[1] <- "EmployeeID"

# difftime () and sapply () function is used to get the time difference(outtime-intime) in hours 
# and Derived new variable "Average Working Hours" from the in and out time of all the employees over the year. 
# here we have consider all the columns (2:250) of in/out datafiles except employeeid 
# rowMeans () function is used to calculate daily avg working hours over the year of each employee
empdata_time <- data.frame(sapply(2:250, function(i) difftime(time1 = out_time[,i], time2 = in_time[,i], units = "hours")))
empdata_time$AvgworkingHrs <- as.integer(rowMeans(empdata_time,na.rm = T))

# cbind() function is used to comnbine EmployeeId column  which we have exclude above during calculation of avg working hrs  
# created a dataframe with two columns EmployeeId and Avgworkinghrs and merge this dataframe to "empdata" dataframe 
# Created a new merged dataframe "empdata_final" which has all the columns of all 5 datafiles along with derived column AvgWorking hrs.
#"empdata_final" dataframe has 4410 observation of 27 variables
empdata_time <- cbind(EmployeeID = in_time$EmployeeID, empdata_time)
empdata_t <- empdata_time[,c(1,251)]
empdata_final <- merge(empdata,empdata_t, by="EmployeeID", all = T)

# Duplicate Check on final merged dataframe which shows there is no duplicate value in employeeid column
empdata_final <- empdata_final[!duplicated(empdata_final),]

# NA treatment on final merged dataframe
sapply(empdata_final, function(x) sum(is.na(x)))
## EnvironmentSatisfaction  JobSatisfaction   WorkLifeBalance  NumCompaniesWorked TotalWorkingyears      
##       25                      20             38                     19               9
# we have total 4410 observations out of which total count of NA's value are 111 . 
# So,best is to remove these observations from the total number of analysis
# now "empdata_final" dataframe has 4300 observations of 27 variables
empdata_final <- empdata_final[rowSums(is.na(empdata_final)) <= 0.01,]

## outlier treatment on final merged dataframe
## boxplot and quantile shows there are no outliers in mothlyincome column 
quantile(empdata_final$MonthlyIncome,seq(0,1,.01),na.rm = T) 
boxplot(empdata_final$MonthlyIncome)

# write.csv() function is used to write the data to the desired excel file which can be used for plotting in Tableau
# write.csv(empdata_final,"empdata_final_24_nov.csv")

###########################################################################################################
## 3) Exploratory Data Analysis using Plots

bar_theme1<- theme_gray() + theme(axis.text.x = element_text(angle = 50, hjust = 1), 
                                  legend.position="none")

## 1) Univariate Analysis
# 1.1) department and Business travelwise attrition trends
plot_grid(ggplot(empdata_final, aes(x=Department,fill = Attrition)) + geom_bar() + labs(y="count",title="Department wise trends") +
  geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+bar_theme1,
  ggplot(empdata_final, aes(x=BusinessTravel,fill = Attrition)) + geom_bar() + labs(y="count",title="Business Travel wise trends") +
    geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+bar_theme1)
# We observed that "Research & development" department sees more attrition as compared to other departments
# We observed that "More frequent business travelr" sees more attrition as compared rare and no traveler

# 1.2) Gender and Marital status wise attrition trends 
plot_grid(ggplot(empdata_final, aes(x=Gender,fill = Attrition)) + geom_bar() + labs(y="count",title="Gender wise trends") +
    geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+bar_theme1,
    ggplot(empdata_final, aes(x=MaritalStatus,fill = Attrition)) + geom_bar() + labs(y="count",title="Marital status wise trends") +
      geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+bar_theme1,align = "v",ncol = 1)
# We observed that "Single" marital status sees more attrition as compared to other status Married and divorced
# We observed that "Male" sees a slight more attrition as compared to Female

# 1.3) Education field and Job Role wise attrition trends
plot_grid(ggplot(empdata_final, aes(x=EducationField,fill = Attrition)) + geom_bar() + labs(y="count",title="Education wise trends") +
            geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+bar_theme1,
            ggplot(empdata_final, aes(x=JobRole,fill = Attrition)) + geom_bar() + labs(y="count",title="Job Role wise trends") +
            geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_stack(vjust=0.6))+bar_theme1,align = "h") 
# We observed that "Life Science" education field sees more attrition as compared to other fields.
# We observed that "Sales and Research" job roles seesmore attrition as compared other role.

#2) Boxplot for numerical variables
# 2.1) Monthlyincome and %salaryhike wise attrition trends
plot_grid(ggplot(empdata_final,aes(x=Attrition,y=MonthlyIncome, fill=Attrition))+geom_boxplot()+labs(y="MonthlyIncome",title="Monthly income wise trend")+theme_grey(),
          ggplot(empdata_final,aes(x=Attrition,y=PercentSalaryHike, fill=Attrition))+geom_boxplot()+labs(Y="Salary hike",title="salary hike wise trends")+theme_grey(),
          align = "v",nrow = 1)

# 2.2) Total workingyears and number of companies worked wise attrition trends
plot_grid(ggplot(empdata_final,aes(x=Attrition,y=TotalWorkingYears, fill=Attrition))+geom_boxplot()+labs(y="TotalWorkingYears",title="TotalWorkingYears wise trend")+theme_grey(),
          ggplot(empdata_final,aes(x=Attrition,y=NumCompaniesWorked, fill=Attrition))+geom_boxplot()+labs(y="No.of companies",title="Comapnies worked wise trends")+theme_grey(),
          align = "v",nrow = 1)
# We observed that "less number of years of exp." sees more attrition as compared to more working years of exp.
# We observed that "less number of companies worked" sees more attrition as compared to more.

# 2.3) Years at company and years since last promotion wise attrition trends
plot_grid(ggplot(empdata_final,aes(x=Attrition,y=YearsAtCompany, fill=Attrition))+geom_boxplot()+labs(y="YearsAtCompany",title="years wise trend")+theme_grey(),
          ggplot(empdata_final,aes(x=Attrition,y=YearsAtCompany, fill=Attrition))+geom_boxplot()+labs(y="YearsSinceLastPromotion",title="Promotion years wise trends")+theme_grey(),
          align = "v",nrow = 1)
# We observed that "less number of years at comapny" sees more attrition.

# 2.4) Avg working hrs and Performance rating wise attrition trends
ggplot(empdata_final,aes(x=Attrition,y=AvgworkingHrs, fill=Attrition))+geom_boxplot()+labs(y="AvgworkingHrs",title="Avg working hrs wise trend")+theme_grey()
ggplot(empdata_final,aes(x=PerformanceRating,fill=Attrition))+
        geom_bar(stat= "count",position="dodge")+
        labs(x="Rating", y="Number of request",title="Performance rating wise attrition trneds")+
        geom_text(stat="count",aes(label=..count..,y = ..count..),position=position_dodge(width=1.0),vjust=-0.25)+
        theme_bw()
# We observed that "rating below 5" sees more attrition.

# Correlation between numeric variables
ggpairs(empdata_final[, c("EnvironmentSatisfaction", "JobSatisfaction", "WorkLifeBalance","JobInvolvement")])
## We can see that none of these variables show a high correlation. 
ggpairs(empdata_final[,c("AvgworkingHrs","MonthlyIncome","PercentSalaryHike")])
## We can see that none of these variables show a high correlation. 
ggpairs(empdata_final[,c("TotalWorkingYears","NumCompaniesWorked","YearsAtCompany")])
## We can see that total working years and years at company have a high correlation. 

############################################################################################################
## 4)  Feature standardisation

# Checking Attrition rate of prospect Employee which comes as 16.16%
## ifelse() function is used to convert level Yes to 1 and No to 0 respectively. 
empdata_final$Attrition<- ifelse(empdata_final$Attrition=="Yes",1,0)
AttritionRate <- sum(empdata_final$Attrition)/nrow(empdata_final)
AttritionRate 

# Getting the leveles of the variables in the correct character format like low, medium , high etc.  
# a) creating function to convert satisfaction Levels to respective categories:
Fun_satisfaction <- function(P_satisfaction)
{
  if (P_satisfaction==1)
    return("Low")
  else if (P_satisfaction==2)
    return("Medium")
  else if (P_satisfaction==3)
    return("High")
  else if (P_satisfaction==4)
    return("Very High")
}
## USing sapply() to apply the same function to a range of values. 
empdata_final$EnvironmentSatisfaction <- sapply(empdata_final$EnvironmentSatisfaction,Fun_satisfaction)
empdata_final$JobInvolvement <- sapply(empdata_final$JobInvolvement,Fun_satisfaction)
empdata_final$JobSatisfaction <- sapply(empdata_final$JobSatisfaction,Fun_satisfaction)

# b) Creating function to convert Education Level to respective categories ;
functedulevel <- function(level)
{
  if (level==1)
    return("Below College")
  else if (level==2)
    return("College")
  else if (level==3)
    return("Bachelor")
  else if (level==4)
    return("Master")
  else if (level==5)
    return("Doctor")
}
empdata_final$Education <- sapply(empdata_final$Education,functedulevel)

# c) Creating function to convert Performance Rating Level to respective categories ;
functrating <- function(rating)
{
  if (rating==1)
    return("Low")
  else if (rating==2)
    return("Good")
  else if (rating==3)
    return("Excellent")
  else if (rating==4)
    return("Outstanding")
}
empdata_final$PerformanceRating <- sapply(empdata_final$PerformanceRating,functrating)

## d) Creating function to convert Work_Life_Balance Level to respective categories ;
functwlb <- function(wlb)
{
  if (wlb==1)
    return("Bad")
  else if (wlb==2)
    return("Good")
  else if (wlb==3)
    return("Better")
  else if (wlb==4)
    return("Best")
  }
empdata_final$WorkLifeBalance <- sapply(empdata_final$WorkLifeBalance,functwlb)

# Normalising continuous features 
## apply function scale() to all the numeric variables so that high values of any particular varible doesnt have a disproportionate effect on the model. 
# Scale : Age,DistanceFromHome ,MonthlyIncome,PercentSalaryHike,TotalWorkingYears,TrainingTimesLastYear,
# YearsAtCompany ,YearsSinceLastPromotion, YearsWithCurrManager,Average_hours

empdata_final$Age <- scale(empdata_final$Age)
empdata_final$DistanceFromHome <- scale(empdata_final$DistanceFromHome)
empdata_final$MonthlyIncome <- scale(empdata_final$MonthlyIncome)
empdata_final$NumCompaniesWorked <- scale(empdata_final$NumCompaniesWorked)
empdata_final$PercentSalaryHike <- scale(empdata_final$PercentSalaryHike)
empdata_final$TotalWorkingYears <- scale(empdata_final$TotalWorkingYears)
empdata_final$TrainingTimesLastYear <- scale(empdata_final$TrainingTimesLastYear) 
empdata_final$YearsAtCompany <- scale(empdata_final$YearsAtCompany)
empdata_final$YearsSinceLastPromotion <- scale(empdata_final$YearsSinceLastPromotion)
empdata_final$YearsWithCurrManager <- scale(empdata_final$YearsWithCurrManager)
empdata_final$AvgworkingHrs <- scale(empdata_final$AvgworkingHrs)

# Dummy variable creation
# For Categorical variables with 2 levels; the categories were converted into levels 0 and 1 using level() 
# For Categorical variables with 3 and more leves; dummy variables were created using model.matrix()
# converting target variable Attrition from No/Yes character to factorwith levels 0/1 
# Creating a separate dataframe "empdata_chr" for Character variables 
empdata_final$Gender<- ifelse(empdata_final$Gender=="Female",1,0)
empdata_chr <- empdata_final[,c(4,5,7,8,10:12,16,22:26)]

# converting categorical attributes to factor before creating dummies variables
empdata_fact<- data.frame(sapply(empdata_chr, function(x) factor(x)))
str(empdata_fact)

dummies<- data.frame(sapply(empdata_fact,function(x) data.frame(model.matrix(~x-1,data =empdata_fact))[,-1]))

#Created final Data frame "employee_data_final" with all columns,derived column and dummies variables using cbind()
# In which we have total 4300 obs of 56 variables
employee_data_final<- cbind(empdata_final[,-c(4,5,7,8,10:12,16,22:26)],dummies) 
# removing employeeid column from final dataframe as this will be not needed during model creation
employee_data_final<- employee_data_final[,-1]
str(employee_data_final) # having all numeric column

############################################################################################################
## splitting the data between train and test
#set.seed () function is used for reproducible random number results
set.seed(100)
# traindata set has 3010 obs of 56 variables
# testdata set has 1290 obs of 56 variables
indices = sample.split(employee_data_final$Attrition, SplitRatio = 0.7)
traindata = employee_data_final[indices,] 
testdata = employee_data_final[!(indices),]
############################################################################################################
## 5) Logistic Regression: Model Building  

# Initial model containing all variables
#Model_1 - AIC 2118.8 nullDev 2661.4 resDev 2006.8
model_1 = glm(Attrition ~ ., data = traindata, family = "binomial")
summary(model_1) 

# Stepwise selection
## In stepAIC function, we pass our first model i.e model_1 and direction is ser as both, because in stepwise,  
## both the forward selection of variables and backward elimination of variables happen simultaneously 
# stepAIC makes multiple calls while checking which variables to keep
# The last call that step makes, contains only the variables it considers to be important in the model. 
# some insignifican variables have been removed. store the last model equation of stepwise method into an object called model_2


#Model_2 -  AIC 2093.6 nullDev 2661.4 resDev 2021.6
model_2<- stepAIC(model_1, direction="both")
# Let us look at the summary of the model 
summary(model_2)

# Removing multicollinearity through VIF check
sort(vif(model_2))

# Steps to be followed while building models are 
## I) Check for high value of VIFs sort() use to get the data in order
## II) check the p values of variable, if the value is high (>0.05) then remove the variable and 
## III) if the high vif variable has very low p value then pick the second highest vif and perform the same steps
## IV) checkpoint is after removing variable check the AIC value that should not dropped drastically. 

## As we can see the highest VIFs have their p values very significants so these variables are statiscally significant and we can't remove.
## follow the above steps for each highest VIFs variables until you get the variable with high VIF and Comparatively low P value 

#Model_3 - Removed variable -  BusinessTravel.xTravel_Rarely VIF-3.515294 and p value- 0.004786 and 
#AIC 2100.4 nullDev 2661.4 resDev 2030.4
model_3 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                 Education.xDoctor + EducationField.xLife.Sciences + EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xHuman.Resources + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xMarried + MaritalStatus.xSingle + 
                 StockOptionLevel.x1 + StockOptionLevel.x3 + EnvironmentSatisfaction.xLow + 
                 EnvironmentSatisfaction.xVery.High + JobSatisfaction.xLow + 
                 JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                 WorkLifeBalance.xGood + JobInvolvement.xMedium + JobInvolvement.xVery.High, 
               family = "binomial", data = traindata)
summary(model_3)
sort(vif(model_3))

#Model_4 - Removed variable -  MaritalStatus.xMarried VIF-2.127809 and p value- 0.043506 and 
#AIC 2102.6 nullDev 2661.4 resDev 2034.6

model_4 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                 Education.xDoctor + EducationField.xLife.Sciences + EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xHuman.Resources + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 StockOptionLevel.x1 + StockOptionLevel.x3 + EnvironmentSatisfaction.xLow + 
                 EnvironmentSatisfaction.xVery.High + JobSatisfaction.xLow + 
                 JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                 WorkLifeBalance.xGood + JobInvolvement.xMedium + JobInvolvement.xVery.High, 
               family = "binomial", data = traindata)
summary(model_4)
sort(vif(model_4))
## cannot exclude any more variable based on vif as most of them have low vif; those with higher vif are very significant and not correlated

#Model_5 - Removed variable -  StockOptionLevel.x3   p value- 0.204025 and 
#AIC 2102.3 nullDev 2661.4 resDev 2036.3

model_5 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                 Education.xDoctor + EducationField.xLife.Sciences + EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xHuman.Resources + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 StockOptionLevel.x1 + EnvironmentSatisfaction.xLow + 
                 EnvironmentSatisfaction.xVery.High + JobSatisfaction.xLow + 
                 JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                 WorkLifeBalance.xGood + JobInvolvement.xMedium + JobInvolvement.xVery.High, 
               family = "binomial", data = traindata)
summary(model_5)

## Now, since all the high VIFs have very low p; so start removing the variables based on high p values one by one .
#Model_6 - Removed variable -  JobLevel.x5    p value- 0.117127 and 
#AIC 2102.9 nullDev 2661.4 resDev 2038.9

model_6 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                 Education.xDoctor + EducationField.xLife.Sciences + EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobRole.xHuman.Resources + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 StockOptionLevel.x1 + EnvironmentSatisfaction.xLow + 
                 EnvironmentSatisfaction.xVery.High + JobSatisfaction.xLow + 
                 JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                 WorkLifeBalance.xGood + JobInvolvement.xMedium + JobInvolvement.xVery.High, 
               family = "binomial", data = traindata)
summary(model_6)

#Model_7 - Removed variable -  JobInvolvement.xVery.High    p value- 0.098346 and 
#AIC 2103.6 nullDev 2661.4 resDev 2041.6

model_7 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                 Education.xDoctor + EducationField.xLife.Sciences + EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobRole.xHuman.Resources + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 StockOptionLevel.x1 + EnvironmentSatisfaction.xLow + 
                 EnvironmentSatisfaction.xVery.High + JobSatisfaction.xLow + 
                 JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                 WorkLifeBalance.xGood + JobInvolvement.xMedium, 
               family = "binomial", data = traindata)
summary(model_7)

#Model_8 - Removed variable -  JobInvolvement.xMedium     p value- 0.114526 and 
#AIC 2104.1 nullDev 2661.4 resDev 2044.1

model_8 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                 Education.xDoctor + EducationField.xLife.Sciences + EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobRole.xHuman.Resources + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 StockOptionLevel.x1 + EnvironmentSatisfaction.xLow + 
                 EnvironmentSatisfaction.xVery.High + JobSatisfaction.xLow + 
                 JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                 WorkLifeBalance.xGood , 
               family = "binomial", data = traindata)
summary(model_8)

#Model_9 - Removed variable -  JobRole.xHuman.Resources    p value- 0.099049 and 
#AIC 2105 nullDev 2661.4 resDev 2047.0

model_9 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                 Education.xDoctor + EducationField.xLife.Sciences + EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 StockOptionLevel.x1 + EnvironmentSatisfaction.xLow + 
                 EnvironmentSatisfaction.xVery.High + JobSatisfaction.xLow + 
                 JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                 WorkLifeBalance.xGood , 
               family = "binomial", data = traindata)
summary(model_9)

#Model_10 - Removed variable -  Education.xDoctor     p value- 0.057596 and 
#AIC 2107 nullDev 2661.4 resDev 2051.0

model_10 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                 EducationField.xLife.Sciences + EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 StockOptionLevel.x1 + EnvironmentSatisfaction.xLow + 
                 EnvironmentSatisfaction.xVery.High + JobSatisfaction.xLow + 
                 JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                 WorkLifeBalance.xGood , 
               family = "binomial", data = traindata)
summary(model_10)

#Model_11 - Removed variable -  EnvironmentSatisfaction.xVery.High     p value- 0.036901 and 
#AIC 2109.5 nullDev 2661.4 resDev 2055.5

model_11 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + EducationField.xMarketing + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  JobLevel.x2 + JobRole.xManager + 
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + 
                  StockOptionLevel.x1 + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                  WorkLifeBalance.xGood , 
                family = "binomial", data = traindata)
summary(model_11)

#Model_12 - Removed variable -  JobRole.xManager     p value- 0.023328 and 
#AIC 2113 nullDev 2661.4 resDev 2061.0

model_12 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + EducationField.xMarketing + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  JobLevel.x2  + 
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + 
                  StockOptionLevel.x1 + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                  WorkLifeBalance.xGood , 
                family = "binomial", data = traindata)
summary(model_12)

# Model_13 - Removed variable -  JobLevel.x2     p value- 0.020962 and 
#AIC 2116.3 nullDev 2661.4 resDev 2066.3

model_13 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + EducationField.xMarketing + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + 
                  StockOptionLevel.x1 + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                  WorkLifeBalance.xGood , 
                family = "binomial", data = traindata)
summary(model_13)

# Model_14 - Removed variable -  StockOptionLevel.x1     p value- 0.009977 and 
#AIC 2121.1 nullDev 2661.4 resDev 2073.1

model_14 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + EducationField.xMarketing + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + 
                  EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                  WorkLifeBalance.xGood , 
                family = "binomial", data = traindata)
summary(model_14)

# Model_15 - Removed variable -  JobRole.xResearch.Director     p value- 0.004823 and 
#AIC 2126.5 nullDev 2661.4 resDev 2080.5

model_15 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + EducationField.xMarketing + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  JobRole.xManufacturing.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + 
                  EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                  WorkLifeBalance.xGood , 
                family = "binomial", data = traindata)
summary(model_15)

# Model_16 - Removed variable -  JobRole.xSales.Executive      p value- 0.014584 and 
#AIC 2130.4 nullDev 2661.4 resDev 2086.4

model_16 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + EducationField.xMarketing + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  JobRole.xManufacturing.Director + MaritalStatus.xSingle + 
                  EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                  WorkLifeBalance.xGood , 
                family = "binomial", data = traindata)
summary(model_16)

# Model_17 - Removed variable -  TrainingTimesLastYear      p value- 0.000543 and 
#AIC 2140.7 nullDev 2661.4 resDev 2098.7

model_17 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                   YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + EducationField.xMarketing + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  JobRole.xManufacturing.Director + MaritalStatus.xSingle + 
                  EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                  WorkLifeBalance.xGood , 
                family = "binomial", data = traindata)
summary(model_17)

# Model_18 - Removed variable -  JobRole.xManufacturing.Director      p value- 0.000543 and 
#AIC 2153.5 nullDev 2661.4 resDev 2113.5

model_18 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + EducationField.xMarketing + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High + WorkLifeBalance.xBest + WorkLifeBalance.xBetter + 
                  WorkLifeBalance.xGood , 
                family = "binomial", data = traindata)
summary(model_18)

# Model_19 - Removed variable -  WorkLifeBalance.xBest     p value- 0.000177 and 
#AIC 2165.6 nullDev 2661.4 resDev 2127.6

model_19 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + EducationField.xMarketing + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High  + WorkLifeBalance.xBetter + 
                  WorkLifeBalance.xGood , 
                family = "binomial", data = traindata)
summary(model_19)

# Model_20 - Removed variable -  WorkLifeBalance.xGood      p value- 0.023214 and 
#AIC 2165.6 nullDev 2661.4 resDev 2127.6

model_20 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + EducationField.xMarketing + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High  + WorkLifeBalance.xBetter , 
                family = "binomial", data = traindata)
summary(model_20)

# Model_21 - Removed variable -  WorkLifeBalance.xBetter      p value- 0.000424 and 
#AIC 2168.7 nullDev 2661.4 resDev 2132.7

model_21 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + EducationField.xMarketing + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High , 
                family = "binomial", data = traindata)
summary(model_21)

# Model_22 - Removed variable -  age      p value- 0.000289 and 
#AIC 2190.8 nullDev 2661.4 resDev 2158.8

model_22 <- glm(formula = Attrition ~  NumCompaniesWorked + TotalWorkingYears + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + EducationField.xMarketing + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High , 
                family = "binomial", data = traindata)
summary(model_22)


# Model_23 - Removed variable -  EducationField.xMarketing      p value- 0.000135 and 
#AIC 2202.9 nullDev 2661.4 resDev 2172.9

model_23 <- glm(formula = Attrition ~  NumCompaniesWorked + TotalWorkingYears + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xLife.Sciences + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High , 
                family = "binomial", data = traindata)
summary(model_23)

# Model_24 - Removed variable -  EducationField.xLife.Sciences      p value- 0.0793 and 
#AIC 2203.9 nullDev 2661.4 resDev 2175.9

model_24 <- glm(formula = Attrition ~  NumCompaniesWorked + TotalWorkingYears + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High , 
                family = "binomial", data = traindata)
summary(model_24)

# Model_25 - Removed variable -  EducationField.xMedical      p value- 0.296 and 
# AIC 2203 nullDev 2661.4 resDev 2177.0

model_25 <- glm(formula = Attrition ~  NumCompaniesWorked + TotalWorkingYears + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + 
                  EducationField.xOther + EducationField.xTechnical.Degree + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High , 
                family = "binomial", data = traindata)
summary(model_25)

# Model_26 - Removed variable -  EducationField.xOther      p value- 0.21827 and 
# AIC 2202.6 nullDev 2661.4 resDev 2178.6

model_26 <- glm(formula = Attrition ~  NumCompaniesWorked + TotalWorkingYears + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently + EducationField.xTechnical.Degree + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High , 
                family = "binomial", data = traindata)
summary(model_26)

# Model_27 - Removed variable -  EducationField.xTechnical.Degree      p value- 0.133153 and 
# AIC 2203 nullDev 2661.4 resDev 2181.0

model_27 <- glm(formula = Attrition ~  NumCompaniesWorked + TotalWorkingYears + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently  + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow + 
                  JobSatisfaction.xVery.High , 
                family = "binomial", data = traindata)
summary(model_27)

# Model_28 - Removed variable -  JobSatisfaction.xVery.High      p value- 0.00011 and 
# AIC 2216.5 nullDev 2661.4 resDev 2196.5

model_28 <- glm(formula = Attrition ~  NumCompaniesWorked + TotalWorkingYears + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  AvgworkingHrs + BusinessTravel.xTravel_Frequently  + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.xLow + JobSatisfaction.xLow, 
                family = "binomial", data = traindata)
summary(model_28)

## Now all the values of thep are very low. Hence, our final model 
# We have finaize the model With 9 significant variables which are
# NumCompaniesWorked ,       AvgworkingHrs
# TotalWorkingYears          BusinessTravel.xTravel_Frequently
# YearsSinceLastPromotion    MaritalStatus.xSingle
# YearsWithCurrManager ,     EnvironmentSatisfaction.xLow   JobSatisfaction.xLow
#Null deviance: 2661.4  on 3009  degrees of freedom
#Residual deviance: 2196.5  on 3000  degrees of freedom
#AIC: 2216.5
final_model<- model_28

############################################################################################################
## 6) Logistic Regression: Model Evaluation
# In a model evaluation process, we use our model that has been prepared with the help of training data, 
# to make predictions for the testing data. We used below methods to evaluate the model
# i) Accuracy-Sensitivity-Specificity ii) KS Statistic iii) Gain-Lift  

# A) Acuracy-Sensitivity-Specificity
# predict() function is used to predict probabilities of attrition for test data
# Input to predict function - our final_model(model_number 28) and type as response to get the output in terms of probability
# We need to exclude Attrition column as it is the dependent variable

test_pred = predict(final_model, type = "response", 
                    newdata = testdata[-2])

# Let's see the Min and Max values using summary function() which give us the prediction range on testdata from .06% TO 80% 
summary(test_pred)
# Let's append this prediction variable to testdata set and view 
testdata$prob <- test_pred
View(testdata)

# Here we have probabilities for each data points(employeeid) so now we can make the decision whether the employee will turnover or not based on some cutoff value 
# To calculate the cutoff value we use table/ConfusionMatrix which measure the performance of a classification model

test_actual_attrition <- factor(ifelse(testdata$Attrition==1,"Yes","No"))

perform_fn <- function(cutoff) 
{
  predicted_attrition <- factor(ifelse(test_pred >= cutoff, "Yes", "No"))
  conf <- confusionMatrix(predicted_attrition, test_actual_attrition, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}
# Creating cutoff values from prediction range (from min.06% to max 80%) for plotting and initiallizing a matrix of 100 X 3.
s = seq(.01,.80,length=100)
OUT = matrix(0,100,3)
for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 
## Plotting the Sensitivity,Specificity and Accuracy of the model to identify the final cut off value. 
plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))

## Getting the cutoff value. 
cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.01)]
cutoff  #0.1775
# So based on the above plot we choose a cutoff value of 0.1775 for final model
# since we are focusing on employees who will churn and that is capture in sensitivity so 
# when the cutoff is increased,its sensitivity decrease and specificity increase so we choose 0.1775 as cutoff 
test_cutoff_attrition <- factor(ifelse(test_pred >=0.1775, "Yes", "No"))

# Here the confusion matrix gives us 3 measures which shows how well our model dscriminates between two classes
#Sensitivity is a ratio which gives true positive rate which came 0.7512 for final model
#Specificity is a ratio which gives true negative rate which came 0.7512 for final model0.7502
#Accuracy - is a ratio which gives sum of true positive and true negative divided by all observation i.e. 0.7504
conf_final <- confusionMatrix(test_cutoff_attrition, test_actual_attrition, positive = "Yes")
acc <- conf_final$overall[1]
sens <- conf_final$byClass[1]
spec <- conf_final$byClass[2]

# B) KS -statistic - 
## Assigning numeric values 1 and o for Yes and No values of predicted and actual attrition 
test_cutoff_attrition <- ifelse(test_cutoff_attrition=="Yes",1,0)
test_actual_attrition <- ifelse(test_actual_attrition=="Yes",1,0)
# prediction() function is used to create prediction objects based on the actual and predicted cutoff attrition  
# Performance() function is used to to perofrm all kinds of predictor evaluations.
# here we use parameters tpr (true positive rate) & fpr (false positive rate)

pred_object_test<- prediction(test_cutoff_attrition, test_actual_attrition)
performance_measures_test<- performance(pred_object_test, "tpr", "fpr")

#plot sensitivity/specificity curve (x-axis:specificity,y-axis:sensitivity)
plot(performance_measures_test)

# Calculating KS Statistic value 
ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])
max(ks_table_test) 
##KS statistic comes 50.14# which shows that our model is good and lies in the top deciles

# C) Lift & Gain Chart 
#The gain statistic is a clear indicator of the advantage offered by the model
#The Lift tells us the factor by whichmodel is outperforming a random model, i.e. a model-less situation.

lift <- function(labels , predicted_prob,groups=10) {
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups))) 
  return(gaintable)
}

# as observed that table shows when using our best fit model vs random model then 
# at the 4th decile we'll be able to identified ~80% of the employees who can churn.
Attrition_decile = lift(test_actual_attrition, test_pred, groups = 10)

#bucket total totalresp Cumresp  Gain Cumlift
#1      1   129        79      79  37.8    3.78
#2      2   129        41     120  57.4    2.87
#3      3   129        26     146  69.9    2.33
#4      4   129        19     165  78.9    1.97
#5      5   129        10     175  83.7    1.67
# ....
#10     10   129         6     209 100      1  

# graph for lift
graphics::plot(Attrition_decile$bucket, Attrition_decile$Cumlift, type="l", ylab="Cumulative lift", xlab="Bucket")

####################################################################################################

