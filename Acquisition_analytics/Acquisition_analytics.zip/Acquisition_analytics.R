##Assignment : Acquisition Analytics 
## Bank Marketing Data 
# Submitted By : Rupashi Jain 
#----------------------------------------------------------
# The standard process followed in analytics projects is:
# 1. Business Understanding
# 2. Data Understanding  
# 3. Data Preparation
# 4. Modelling
# 5. Model Evaluation
# 6. Model Deployment and Recommendations

#-------------------------------------------------------
## Business Understanding:- Prospect Profiling
#-------------------------------------------------------
## Loading all the necessary libraries 
## 
library(ggplot2)
library(caret)
library(caTools)
#install.packages("dummies")
library(dummies)
library(dplyr)
library(tidyr)
library(MASS)
library(car)
library(e1071)
library(caret)
# Loading bank marketing data in the working directory. 
# Seeting the working directory 
## setwd("~/rupashi/Data Science/Domain_elective")

bank_data<- read.csv("bank_marketing.csv")

# Checking structure of dataset 

str(bank_data)

# Summary of dataset

summary(bank_data)

#-------------------------------------------------------

# Checking response rate of prospect customer

response <- 4640/(36548+4640)
response

# Checking missing values

sum(is.na(bank_data))

#-------------------------------------------------------

# Loading ggplot2 library


# Plotting Age histogram
ggplot(bank_data,aes(age))+geom_histogram()

# Let's check the outlier in the variables 

quantile(bank_data$age,seq(0,1,0.01))

# Box plot 

boxplot(bank_data$age)

# Capping the upper values of age with 71.

bank_data[(which(bank_data$age>71)),]$age <- 71


# Binning the age variable and store it into "binning.age".

bank_data$binning.age <- as.factor(cut(bank_data$age, breaks = c(16, 20, 30, 40, 50, 60, 70, 80)))

# Change the response value to numbers i.e"yes-no" to "1-0"

bank_data$response <- ifelse(bank_data$response == "yes", 1, 0)

# Check the numeric value of response rate in each bucket

agg_age <- merge(aggregate(response ~ binning.age, bank_data, mean),aggregate(response~binning.age, bank_data, sum),by = "binning.age") 

# Adding No.of_prospect
count <- data.frame(table(bank_data$binning.age))
count <- count[,-1]
agg_age <- cbind(agg_age,count)


# changing column name of each variables in agg_age dataframe

colnames(agg_age) <- c("age", "response_rate", "count_prospects","No.of_prospect")

# Round Off the values

agg_age$response_rate <- format(round(agg_age$response_rate, 2))

agg_age

#-------------------------------------------------------

# Let's see the response rate of each age bucket in the plot

ggplot(agg_age, aes(age, No.of_prospect,label = response_rate)) + 
  geom_bar(stat = 'identity') + theme(axis.text.x = element_text(angle = 60, hjust = 1)) + 
  geom_text(size = 3, vjust = -0.5)

# Let's check the dataset of age less than 20 years. 
Bank_data_age20 <- subset(bank_data,age <20)

#View(Bank_data_age20)
summary(Bank_data_age20)

##--------------------------------------------------------  

# Checking structure of dataset

str(bank_data)

#-----Next Variable is "job"

# Checking the levels of the job

levels(bank_data$job)


# Plotting bar graph for job variable.

# Writing a function "plot_response" to do the same task for each variable

plot_response <- function(cat_var, var_name){
  a <- aggregate(response~cat_var, bank_data, mean)
  count <- data.frame(table(cat_var))
  count <- count[,-1]
  agg_response <- cbind(a, count)
  
  colnames(agg_response) <- c(var_name, "response_rate","No.of_Prospect")
  agg_response[, 2] <- format(round(agg_response[, 2], 2))
  
  ggplot(agg_response, aes(agg_response[, 1], count, label = response_rate)) + geom_bar(stat = 'identity') + theme(axis.text.x = element_text(angle = 60, hjust = 1)) + geom_text(size = 3, vjust = -0.5) + xlab(var_name)
  
}

plot_response(bank_data$job, "job")

##--------------------------------------------------------  

# Checking structure of dataset 

str(bank_data)

# Checking Marital status

summary(bank_data$marital)

# Let's replace Unknown level to married

levels(bank_data$marital)[4] <- "married"

# Plotting marital status

plot_response(bank_data$marital,"marital")

# Let's see the education variables

plot_response(bank_data$education,"Education")



# Reducing the levels of education variable

levels(bank_data$education)[c(1:3,5)] <- "Primary_Education"
levels(bank_data$education)[2] <- "Secondary_Education"
levels(bank_data$education)[4]<- "Tertiary_Education"

# Let's again check the education plot


plot_response(bank_data$education,"Education_levels")


#-------------------------------------------------------
# Let's see the default variable

table(bank_data$default)

plot_response(bank_data$default, "Default")
bank_data <- bank_data[,-5]

#-------------------------------------------------------

# Let's understand the housing variables 

summary(bank_data$housing)


plot_response(bank_data$housing, "Housing")

#-------------------------------------------------------

#-- Let's see the next variable which is "loan"

summary(bank_data$loan)

plot_response(bank_data$loan, "Loan Status")
#-------------------------------------------------------
#  Next variable is Contact, Let's see the response rate of each mode 

summary(bank_data$contact)
plot_response(bank_data$contact,"Contact_mode")

#-------------------------------------------------------

# Next variable is "Month" i.e contact month. 

plot_response(bank_data$month,"Contact_month")

#-------------------------------------------------------

# Let's do the same of "day_of_week" variable

plot_response(bank_data$day_of_week,"day_of_week")

#-------------------------------------------------------

# Now, Let's see the "duration" variable: Which is Quantitative variable

# Let's check the histogram 

ggplot(bank_data,aes(duration))+geom_histogram()

# Let's see the summary of this variable once 

summary(bank_data$duration)

# Average duration 
bank_data$response_1 <- as.factor(bank_data$response)
Avg_duration <- aggregate(duration~response_1,bank_data,mean)

Avg_duration

bank_data <- bank_data[,-22]

## Definitely the outlier is present in the dataset

# So let's check the percentile distribution of duration 

quantile(bank_data$duration,seq(0,1,0.01))


# So, capping the duration seconds at 99% which is 1271.3sec 

bank_data[(which(bank_data$duration>1271.13)),]$duration <- 1271.13

# Now, again plot the histogram 

ggplot(bank_data,aes(duration))+geom_histogram()

#-------------------------------------------------------

# the next variable is "campaign" variable
#(number of contacts performed during this campaign and for this client 
# numeric, includes last contact)

# So let's check the summay of this variable 

summary(bank_data$campaign)

# Let's see the percentile distribution of this variable

boxplot(bank_data$campaign)


quantile(bank_data$campaign,seq(0,1,0.01))

# Capping this at 99% which the value is 14

bank_data[which(bank_data$campaign>14),]$campaign <- 14

# Visualizing it with plot

ggplot(bank_data,aes(campaign))+geom_histogram()

#-------------------------------------------------------
#-- Next variable is "pdays"
# Let's first convert this variable to factor type

bank_data$pdays<- as.factor(bank_data$pdays)

# Checking summary

summary(bank_data$pdays)

levels(bank_data$pdays)

# Reducing the levels of this variable to 3.

levels(bank_data$pdays)[1:10] <- "Contacted_in_first_10days"
levels(bank_data$pdays)[2:17] <-"Contacted_after_10days"
levels(bank_data$pdays)[3] <- "First_time_contacted"


# Also,lets see the respose rate of each levels. 

plot_response(bank_data$pday,"Pday")

# Number of prospects under each category

table(bank_data$pdays)

#-------------------------------------------------------

# Next variable is "previous" i.e number of contacts performed before 
# this campaign and for this client (numeric)

summary(bank_data$previous)
# Max=7, best is to convert this variable to factor

bank_data$previous <- as.factor(bank_data$previous)

levels(bank_data$previous)[1]<-"Never contacted"
levels(bank_data$previous)[2:4] <- "Less_than_3_times"
levels(bank_data$previous)[3:6] <- "More than_3_times"


summary(bank_data$previous)


plot_response(bank_data$previous,"Previous_contacts")


# Now, the next variable is "Poutcome" i.e  outcome of the previous marketing campaign 
# (categorical: 'failure','nonexistent','success')

summary(bank_data$poutcome)

plot_response(bank_data$poutcome,"Outcome_of_Previous_contacts")

-------------------------------------------------------------------------------------------------

  #-- social and economic context attributes
  
  # emp.var.rate- :employment variation rate - quarterly indicator (numeric)
  summary(bank_data$emp.var.rate)

# Histogram of employment variation rate variable
ggplot(bank_data,aes(emp.var.rate))+geom_histogram()

# cons.price.idx:consumer price index - monthly indicator (numeric) 
summary(bank_data$cons.price.idx)

# Histogram of consumer price index variable
ggplot(bank_data,aes(cons.price.idx))+geom_histogram()

# cons.conf.idx: consumer confidence index - monthly indicator (numeric) 
summary(bank_data$cons.conf.idx)

# euribor3m: euribor 3 month rate - daily indicator (numeric)
summary(bank_data$euribor3m)

# nr.employed: number of employees - quarterly indicator (numeric)
summary(bank_data$nr.employed)

#----------------------------------------------------------------------------

## Removing variable binning age

str(bank_data)

bank_data <- bank_data[, -21]

#creating dummy variables

bank_data$response <- as.integer(bank_data$response)

##k1 <- bank_data

bank_data <- dummy.data.frame(bank_data)

##bank_data <- bank_data[,-c(62:68)]

##bank_data <- bank_data[,-45]

str(bank_data)

bank_data$response <- as.factor(ifelse(bank_data$response == 1, "yes", "no"))

#---------------------------------------------------------    

# splitting into train and test data for model building 
#set.seed () function is used for reproducible random number results
set.seed(100)

split_indices <- sample.split(bank_data$response, SplitRatio = 0.70)

## Excluding variable Duration in the train data set for building the model without this variable.  

train <- bank_data[split_indices, -45 ]

test <- bank_data[!split_indices, ]

nrow(train)/nrow(bank_data)

nrow(test)/nrow(bank_data)

#---------------------------------------------------------    

### Logistic Regression: Model Building  
## Model 1 contains all the variables. 

logistic_1 <- glm(response ~ ., family = "binomial", data = train)

summary(logistic_1)

#---------------------------------------------------------    

# Using stepwise algorithm for removing insignificant variables . 

## In stepAIC function, we pass our first model i.e logistic_1 and direction is ser as both, because in stepwise,  
## both the forward selection of variables and backward elimination of variables happen simultaneously 
# stepAIC makes multiple calls while checking which variables to keep
# The last call that step makes, contains only the variables it considers to be important in the model. 
# some insignifican variables have been removed. store the last model equation of stepwise method into an object called model_2


## logistic_2 <- stepAIC(logistic_1, direction = "both")

##summary(logistic_2)
## StepAIC gave the below results. These variables were further used to build the next model . 
## Call:
##glm(formula = response ~ age + jobretired + loanno + contactcellular + 
##      monthaug + monthdec + monthjun + monthmar + monthmay + monthnov + 
##      day_of_weekfri + day_of_weekmon + day_of_weekthu + day_of_weektue + 
##      campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
##      previousLess_than_3_times + poutcomefailure + emp.var.rate + 
##      cons.price.idx + cons.conf.idx + euribor3m + nr.employed + 
##      educationTertiary_Education + `jobblue-collar` + jobservices, 
##    family = "binomial", data = train)
##
##Deviance Residuals: 
##  Min       1Q   Median       3Q      Max  
##-2.1122  -0.3866  -0.3179  -0.2612   2.9381  
##
##Coefficients:
##  Estimate Std. Error z value Pr(>|z|)    
##(Intercept)                    -1.958e+02  2.796e+01  -7.001 2.54e-12 ***
##  age                            -5.278e-03  2.200e-03  -2.399 0.016457 *  
## jobretired                      2.323e-01  1.012e-01   2.295 0.021750 *  
##  loanno                          1.118e-01  5.758e-02   1.941 0.052241 .  
## contactcellular                 7.290e-01  7.383e-02   9.873  < 2e-16 ***
##  monthaug                        3.838e-01  9.232e-02   4.157 3.22e-05 ***
##  monthdec                        4.991e-01  2.035e-01   2.453 0.014180 *  
##  monthjun                       -5.915e-01  1.107e-01  -5.342 9.20e-08 ***
##  monthmar                        1.412e+00  1.285e-01  10.989  < 2e-16 ***
##  monthmay                       -4.914e-01  6.548e-02  -7.504 6.18e-14 ***
##  monthnov                       -5.570e-01  9.039e-02  -6.163 7.16e-10 ***
##  day_of_weekfri                 -1.929e-01  6.831e-02  -2.824 0.004750 ** 
##  day_of_weekmon                 -4.454e-01  6.812e-02  -6.539 6.20e-11 ***
##  day_of_weekthu                 -9.635e-02  6.471e-02  -1.489 0.136516    
##day_of_weektue                 -1.244e-01  6.645e-02  -1.872 0.061161 .  
##campaign                       -4.451e-02  1.185e-02  -3.755 0.000173 ***
##  pdaysContacted_in_first_10days  1.017e+00  1.698e-01   5.988 2.12e-09 ***
##  pdaysContacted_after_10days     1.120e+00  2.048e-01   5.471 4.47e-08 ***
##  previousLess_than_3_times       3.327e-01  1.689e-01   1.970 0.048877 *  
##  poutcomefailure                -8.748e-01  1.667e-01  -5.248 1.54e-07 ***
##  emp.var.rate                   -1.367e+00  1.278e-01 -10.699  < 2e-16 ***
##  cons.price.idx                  1.858e+00  1.953e-01   9.517  < 2e-16 ***
##  cons.conf.idx                   2.800e-02  7.677e-03   3.647 0.000265 ***
##  euribor3m                       2.494e-01  1.110e-01   2.246 0.024679 *  
##  nr.employed                     3.851e-03  2.162e-03   1.781 0.074888 .  
##educationTertiary_Education     7.026e-02  4.918e-02   1.429 0.153113    
##jobblue-collar`               -2.108e-01  6.328e-02  -3.331 0.000864 ***
##  jobservices                    -1.867e-01  8.376e-02  -2.229 0.025791 *  
##  ---
##  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
##(Dispersion parameter for binomial family taken to be 1)
##Null deviance: 20299  on 28831  degrees of freedom
##Residual deviance: 15820  on 28804  degrees of freedom
##AIC: 15876
##Number of Fisher Scoring iterations: 6
  
logistic_2 <- glm(formula = response ~ age + jobretired + loanno + contactcellular + 
                          monthaug + monthdec + monthjun + monthmar + monthmay + monthnov + 
                          day_of_weekfri + day_of_weekmon + day_of_weekthu + day_of_weektue + 
                          campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                          previousLess_than_3_times + poutcomefailure + emp.var.rate + 
                          cons.price.idx + cons.conf.idx + euribor3m + nr.employed + 
                          educationTertiary_Education + `jobblue-collar` + jobservices, 
                        family = "binomial", data = train)
# Let us look at the summary of the model
summary(logistic_2)
## AIC : 15876
# Removing multicollinearity through VIF check
# Steps to be followed while building models are 
## I) Check for high value of VIFs sort() use to get the data in order
## II) check the p values of variable, if the value is high (>0.05) then remove the variable and 
## III) if the high vif variable has very low p value then pick the second highest vif and perform the same steps
## IV) checkpoint is after removing variable check the AIC value that should not change drastically.
sort(vif(logistic_2))
## As we can see the highest VIFs have their p values very significants so these variables are statiscally significant and we can't remove.
## follow the above steps for each highest VIFs variables until you get the variable with high VIF and Comparatively low P value 

## Removing euribor3m

logistic_3 <- glm(formula = response ~ age + jobretired + loanno + contactcellular + 
                    monthaug + monthdec + monthjun + monthmar + monthmay + monthnov + 
                    day_of_weekfri + day_of_weekmon + day_of_weekthu + day_of_weektue + 
                    campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                    previousLess_than_3_times + poutcomefailure + emp.var.rate + 
                    cons.price.idx + cons.conf.idx +  nr.employed + 
                    educationTertiary_Education + `jobblue-collar` + jobservices, 
                  family = "binomial", data = train)

summary(logistic_3)
## AIC : AIC: 15879

sort(vif(logistic_3))

## Removing previousLess_than_3_times

logistic_4 <-  glm(formula = response ~ age + jobretired + loanno + contactcellular + 
                     monthaug + monthdec + monthjun + monthmar + monthmay + monthnov + 
                     day_of_weekfri + day_of_weekmon + day_of_weekthu + day_of_weektue + 
                     campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                      poutcomefailure + emp.var.rate + 
                     cons.price.idx + cons.conf.idx +  nr.employed + 
                     educationTertiary_Education + `jobblue-collar` + jobservices, 
                   family = "binomial", data = train)

summary(logistic_4)
## AIC: 15881

sort(vif(logistic_4))
## Removing day_of_weekthu

logistic_5 <- glm(formula = response ~ age + jobretired + loanno + contactcellular + 
                    monthaug + monthdec + monthjun + monthmar + monthmay + monthnov + 
                    day_of_weekfri + day_of_weekmon + day_of_weektue + 
                    campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                    poutcomefailure + emp.var.rate + 
                    cons.price.idx + cons.conf.idx +  nr.employed + 
                    educationTertiary_Education + `jobblue-collar` + jobservices, 
                  family = "binomial", data = train)

summary(logistic_5)
##AIC: 15881

sort(vif(logistic_5))
## cannot exclude any more variable based on vif as all of them have significantly low p values;hence those with higher vif are very significant and not correlated
## Now removing  based on p values ; those variables having higher p values are removedd one by one.  

## Now removing day_of_weektue
logistic_6 <- glm(formula = response ~ age + jobretired + loanno + contactcellular + 
                    monthaug + monthdec + monthjun + monthmar + monthmay + monthnov + 
                    day_of_weekfri + day_of_weekmon +  
                    campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                    poutcomefailure + emp.var.rate + 
                    cons.price.idx + cons.conf.idx +  nr.employed + 
                    educationTertiary_Education + `jobblue-collar` + jobservices, 
                  family = "binomial", data = train)

summary(logistic_6)
##  AIC: 15882


## Removing educationTertiary_Education

logistic_7 <- glm(formula = response ~ age + jobretired + loanno + contactcellular + 
                    monthaug + monthdec + monthjun + monthmar + monthmay + monthnov + 
                    day_of_weekfri + day_of_weekmon +  
                    campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                    poutcomefailure + emp.var.rate + 
                    cons.price.idx + cons.conf.idx +  nr.employed + 
                     `jobblue-collar` + jobservices, 
                  family = "binomial", data = train)

summary(logistic_7)
## AIC: 15881

## Removing loanno

logistic_8 <- glm(formula = response ~ age + jobretired + contactcellular + 
                    monthaug + monthdec + monthjun + monthmar + monthmay + monthnov + 
                    day_of_weekfri + day_of_weekmon +  
                    campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                    poutcomefailure + emp.var.rate + 
                    cons.price.idx + cons.conf.idx +  nr.employed + 
                    `jobblue-collar` + jobservices, 
                  family = "binomial", data = train)

summary(logistic_8)
## AIC : 15883


## Removing day_of_weekfri 

logistic_9 <- glm(formula = response ~ age + jobretired + contactcellular + 
                    monthaug + monthdec + monthjun + monthmar + monthmay + monthnov + 
                     day_of_weekmon +  
                    campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                    poutcomefailure + emp.var.rate + 
                    cons.price.idx + cons.conf.idx +  nr.employed + 
                    `jobblue-collar` + jobservices, 
                  family = "binomial", data = train)

summary(logistic_9)
## AIC: 15885 


## Removing jobretired 

logistic_10 <- glm(formula = response ~ age  + contactcellular + 
                     monthaug + monthdec + monthjun + monthmar + monthmay + monthnov + 
                     day_of_weekmon +  
                     campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                     poutcomefailure + emp.var.rate + 
                     cons.price.idx + cons.conf.idx +  nr.employed + 
                     `jobblue-collar` + jobservices, 
                   family = "binomial", data = train)

summary(logistic_10)
## AIC: 15888


## Removing age 

logistic_11 <- glm(formula = response ~  contactcellular + 
                     monthaug + monthdec + monthjun + monthmar + monthmay + monthnov + 
                     day_of_weekmon +  
                     campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                     poutcomefailure + emp.var.rate + 
                     cons.price.idx + cons.conf.idx +  nr.employed + 
                     `jobblue-collar` + jobservices, 
                   family = "binomial", data = train)

summary(logistic_11)
## AIC: 15889
## Removing monthdec

logistic_12 <- glm(formula = response ~  contactcellular + 
                     monthaug +  monthjun + monthmar + monthmay + monthnov + 
                     day_of_weekmon +  
                     campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                     poutcomefailure + emp.var.rate + 
                     cons.price.idx + cons.conf.idx +  nr.employed + 
                     `jobblue-collar` + jobservices, 
                   family = "binomial", data = train)

summary(logistic_12)

## Removing jobservices 
## AIC : 15893 

logistic_13 <- glm(formula = response ~  contactcellular + 
                     monthaug +  monthjun + monthmar + monthmay + monthnov + 
                     day_of_weekmon +  
                     campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                     poutcomefailure + emp.var.rate + 
                     cons.price.idx + cons.conf.idx +  nr.employed + 
                     `jobblue-collar` , 
                   family = "binomial", data = train)

summary(logistic_13)

## AIC: 15899
## Removing monthaug

logistic_14 <- glm(formula = response ~  contactcellular + 
                       monthjun + monthmar + monthmay + monthnov + 
                     day_of_weekmon +  
                     campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                     poutcomefailure + emp.var.rate + 
                     cons.price.idx + cons.conf.idx +  nr.employed + 
                     `jobblue-collar` , 
                   family = "binomial", data = train)

summary(logistic_14)
## AIC: 15909
## Removing nr.employed 

logistic_15 <- glm(formula = response ~  contactcellular + 
                     monthjun + monthmar + monthmay + monthnov + 
                     day_of_weekmon +  
                     campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                     poutcomefailure + emp.var.rate + 
                     cons.price.idx + cons.conf.idx +   
                     `jobblue-collar` , 
                   family = "binomial", data = train)

summary(logistic_15)

## AIC: 15914
## Now all the variables have significantly low p values, hence this is the final model. 
##  We have finaize the model With 14 significant variables which are contactcellular,
##monthjun , monthmar, monthmay , monthnov , day_of_weekmon , 
##  campaign , pdaysContacted_in_first_10days , pdaysContacted_after_10days ,  poutcomefailure , emp.var.rate 
##  cons.price.idx ,cons.conf.idx , 
##  `jobblue-collar` 

logistic_final <- logistic_15
#--------------------------------------------------------- 
# In a model evaluation process, we use our model that has been prepared with the help of training data, 
# to make predictions for the testing data. We used below methods to evaluate the model
# i) Accuracy-Sensitivity-Specificity  iii) Gain-Lift  

# A) Acuracy-Sensitivity-Specificity
# predict() function is used to predict probabilities of attrition for test data
# Input to predict function - our final_model(model_number 15) and type as response to get the output in terms of probability
# We need to exclude Response column as it is the dependent variable

# Predicting probabilities of responding for the test data

predictions_logit <- predict(logistic_final, newdata = test[, -61], type = "response")
summary(predictions_logit)

#--------------------------------------------------------- 

## Model Evaluation: Logistic Regression

# Let's use the probability cutoff of 50%.

predicted_response <- factor(ifelse(predictions_logit >= 0.50, "yes", "no"))

# Creating confusion matrix for identifying the model evaluation.

conf <- confusionMatrix(predicted_response, test$response, positive = "yes")

conf
## Accuracy : 89.8% ,  Sensitivity : 21.5% ,  Specificity : 98.5%

#---------------------------------------------------------    

# Let's find out the optimal probalility cutoff 


perform_fn <- function(cutoff) 
{
  predicted_response <- factor(ifelse(predictions_logit >= cutoff, "yes", "no"))
  conf <- confusionMatrix(predicted_response, test$response, positive = "yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

#---------------------------------------------------------    
summary(predictions_logit)
## Minimum value is 0.01072 and maximum is  0.89263
# Creating cutoff values from 0.01 to 0.99 for plotting and initiallizing a matrix of 100 X 4.

s = seq(.01,.89,length=100)

OUT = matrix(0,100,3)


for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 

#---------------------------------------------------------    

# ## Plotting the Sensitivity,Specificity and Accuracy of the model to identify the final cut off value. 
plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


#---------------------------------------------------------    

cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.10)]
cutoff


# Let's choose a cutoff value of 7.2% for final model

predicted_response <- factor(ifelse(predictions_logit >= 0.0722, "yes", "no"))

conf_final <- confusionMatrix(predicted_response, test$response, positive = "yes")

acc <- conf_final$overall[1]

sens <- conf_final$byClass[1]

spec <- conf_final$byClass[2]

acc

sens

spec

#------------------------------------------------------------------------------

## 3. Creating a data frame with the variables prospect ID, actual response, predicted response, predicted probability of response, duration of call in seconds, and cost of call

test$pred_prob <- predictions_logit
test$pred_response <- predicted_response

## Arranging the test data in decreasing order of the predicted probability. 
## Used function order() for the same. 
test <- test[order(test$pred_prob, decreasing = T), ]

## Creating a new data frame with name test_prospect actual_response,predicted probability,predicted response ,duration and prospect_id.
## Since test data frame already has few of the columns hence used subset() to get only those columns in a different data frame. 
test_prospect <- subset(test,select = c(response,pred_prob,pred_response,duration))

## Creating the column prospect_id 
test_prospect$prospect_id <- 1:nrow(test_prospect)

## Renaming all the columns using colnames()
colnames(test_prospect)<- c("actual_response","predicted_probability","predicted_response","duration","prospect_id")

head(test_prospect)


## Creating the column "cost" for each data point in the test data by using the formula for cost specified in the instructions of the assignment . 

test_prospect$cost <- 0.033*test_prospect$duration +0.8

## Reviewing the structure and records in the newly created data frame. 
str(test_prospect)

head(test_prospect)

## 4 Creating a lift - Gain chart to find the top X% prospects to meet the business objective.  


lift <- function(labels , predicted_prob, groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups)))
  return(gaintable)
}


test_prospect$actual_response <- as.factor(ifelse(test_prospect$actual_response=="yes",1,0))
## Creating a Lift Gain chart
LG = lift(test_prospect$actual_response, test_prospect$predicted_probability, groups = 10)

LG

#   bucket total totalresp Cumresp  Gain Cumlift
# 1      1  1236       591     591  42.5    4.25
# 2      2  1236       266     857  61.6    3.08
# 3      3  1235       116     973  69.9    2.33
# 4      4  1236        86    1059  76.1    1.90
# 5      5  1235        66    1125  80.8    1.62
# 6      6  1236        72    1197  86.0    1.43
# 7      7  1236        59    1256  90.2    1.29
# 8      8  1235        44    1300  93.4    1.17
# 9      9  1236        44    1344  96.6    1.07
#10     10  1235        48    1392 100      1  

## Top 5 deciles will help us reach business objective i.e. contacting 80% of responders at minimum possible cost .  
## Hence the value if X is 50%. 
## We should target top 50% percent of the population to acheive the business target of contacting 80% of responders at minimum possible cost .
## Calculating the average duration of the call. 

## Getting the number of records in top 5 deciles. 
no_of_records <- sum(LG$total[1:5])
no_of_records


## Without building the model we would have contacted  (12356/1392)*1125 = 9986 people to get 1125 responders .
## But after building this model we can target 80% responders by just targetting top 5 deciles of the test population 
## i.e. only 6178 people.

## Calculating average call duration for targeting the top X% prospects.
avg_duration_with_model <- mean(test_prospect$duration[1:no_of_records])

avg_duration_with_model

## Average duration of the top 5 deciles to be targetted to get 80% responders is 267.78 seconds .
## Hence, avergae call duration for targeting the top 50% prospects is 267.78 seconds. 
## Using this average duration we can calculate average cost of a call .

avg_cost_with_model <- mean(test_prospect$cost[1:no_of_records])
avg_cost_with_model

## Avg cost  to get 80% responders when using the model i.e. for the top 50% responders is Rs. 9.63. 

## Comparing Cost per responder with and without using the model model 

## Calculating the cost without using the model . We would have to contact 9986 people to get 1125 responders when not using any model. 
## Calculating the total cost below
cost_without_model <- sum(test_prospect$cost[1:9986])
##Calculating the cost per responder 
cost_without_model/1125

##Cost per responder without using the model comes out to be Rs. 82.1871.

## Calculating the cost when using the model. We can get 1125 responders i.e. 80% by only contacting 6178 people. Hence based on this getting the value of cost per responder. 
## Calculating the total cost below
cost_with_model <- sum(test_prospect$cost[1:6178])

## Calculating the cost per responder . 
cost_with_model/1125 
## Cost per responder when using the model comes out to be Rs. 52.92. 


## Below is a summary of the findings here : 
## 1) When we use our best fit model ; we can get 80% response rate when we target top 5 deciles i.e. top 50% of the prospects. 
## 2) The average call duration for targetting the top 50% of the prospects is 267.78 seconds. 
## 3 ) The cost per responder without using the model was Rs. 82.1871 and when using the model is Rs. 52.92. Hence there is a lift of approx 1.6 which shows we are saving on the cost as well when targetting top 50% of the prospects

#5 
# Lift Chart 

plot(LG$bucket*10,LG$Cumlift,col="red",type="l",main="Lift Chart",xlab="% of total people targeted",ylab = "Lift")

## Lift is defined as the ratio of response rate using the model to the response rate without using the model. 
##The Cumulative Lift of 3.08 for top two deciles,
# means that when selecting 20% of the records based on the model, 
# one can expect 3.4 times the total number of targets (responders) found by randomly 
# selecting 20%-of-records without a model. In terms of cresponders, 
# we can say we can cover 3.4 times the number of responders by selecting only 20% of the
# customers based on the model as compared to 20% customer selection randomly.

### Analyzing the Charts: Cumulative gains and lift charts are a graphical 
# representation of the advantage of using a predictive model to choose which 
# customers to contact. The lift chart shows how much more likely we are to receive
# respondents than if we contact a random sample of customers. For example,
# by contacting only 10% of customers based on the predictive model we will reach 
# 4 times as many respondents as if we use no model.

